<?php
session_start();
include("../modelo/conexion.php");
include("../modelo/clase_clase.php");

$claseObj = new Clase();

### REGISTRAR
if(isset($_POST['registrar']) && $_POST['registrar']=="registrar"){
    $idAlumno      = $_POST['idAlumno']      ?? '';
    $idEntrenador  = $_POST['idEntrenador']  ?? '';
    $idHorarioClase= $_POST['idHorarioClase']?? '';
    $fechaInicio   = $_POST['fechaInicio']   ?? '';
    $fechaFin      = $_POST['fechaFin']      ?? '';

    $resultado = $claseObj->RegistrarClase($idAlumno, $idEntrenador, $idHorarioClase, $fechaInicio, $fechaFin);
    if($resultado['success']){
        $_SESSION['flash'] = ['icon'=>'success','title'=>'Éxito','text'=>'Clase asignada correctamente.'];
        header("Location: ../vista/asignacion_clase/asignacion_clase.php"); exit;
    } else {
        $_SESSION['flash'] = ['icon'=>'error','title'=>'Error','text'=>$resultado['error']];
        header("Location: ../vista/asignacion_clase/insert_asignacion_clase.php"); exit;
    }
}

### LISTAR
if(isset($_GET['L']) && $_GET['L']=="lis"){
    header("Location: ../vista/asignacion_clase/asignacion_clase.php"); exit;
}

### CONSULTAR
if(isset($_GET['C']) && $_GET['C']=="con"){
    $id = $_GET['I'] ?? '';
    if(!is_numeric($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'ID inválido.']; header("Location: ../vista/asignacion_clase/asignacion_clase.php"); exit; }
    $datos = $claseObj->ConsultarClase($id);
    if(!$datos){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'Clase no encontrada.']; header("Location: ../vista/asignacion_clase/asignacion_clase.php"); exit; }
    $p = [
        'id'         => base64_encode($datos['idClase']),
        'alumno'     => base64_encode($datos['nombre_alumno'].' '.$datos['apellido_alumno']),
        'cedula'     => base64_encode($datos['cedula_alumno']),
        'entrenador' => base64_encode($datos['nombre_entrenador'].' '.$datos['apellido_entrenador']),
        'dia'        => base64_encode($datos['diaSemana'] ?? ''),
        'hi'         => base64_encode($datos['horaInicio'] ?? ''),
        'hf'         => base64_encode($datos['horaFin'] ?? ''),
        'fi'         => base64_encode($datos['fechaInicio']),
        'ff'         => base64_encode($datos['fechaFin'] ?? ''),
    ];
    $qs = http_build_query($p);
    header("Location: ../vista/asignacion_clase/detalle_asignacion_clase.php?$qs"); exit;
}

### MOSTRAR (editar)
if(isset($_GET['M']) && $_GET['M']=="mos"){
    $id = $_GET['I'] ?? '';
    if(!is_numeric($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'ID inválido.']; header("Location: ../vista/asignacion_clase/asignacion_clase.php"); exit; }
    $datos = $claseObj->ConsultarClase($id);
    if(!$datos){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'Clase no encontrada.']; header("Location: ../vista/asignacion_clase/asignacion_clase.php"); exit; }
    $p = [
        'id'           => base64_encode($datos['idClase']),
        'idAlumno'     => base64_encode($datos['idAlumno']),
        'idEntrenador' => base64_encode($datos['idEntrenador']),
        'idHorario'    => base64_encode($datos['idHorarioClase']),
        'fechaInicio'  => base64_encode($datos['fechaInicio']),
        'fechaFin'     => base64_encode($datos['fechaFin'] ?? ''),
    ];
    $qs = http_build_query($p);
    header("Location: ../vista/asignacion_clase/edit_asignacion_clase.php?$qs"); exit;
}

### ACTUALIZAR
if(isset($_POST['actualizar']) && $_POST['actualizar']=="actualizar"){
    $id           = base64_decode($_POST['id'] ?? '');
    $idAlumno     = $_POST['idAlumno']       ?? '';
    $idEntrenador = $_POST['idEntrenador']   ?? '';
    $idHorario    = $_POST['idHorarioClase'] ?? '';
    $fechaInicio  = $_POST['fechaInicio']    ?? '';
    $fechaFin     = $_POST['fechaFin']       ?? '';

    $resultado = $claseObj->ActualizarClase($id, $idAlumno, $idEntrenador, $idHorario, $fechaInicio, $fechaFin);
    if($resultado['success']){
        $_SESSION['flash'] = ['icon'=>'success','title'=>'Éxito','text'=>'Clase actualizada correctamente.'];
        header("Location: ../vista/asignacion_clase/asignacion_clase.php"); exit;
    } else {
        $_SESSION['flash'] = ['icon'=>'error','title'=>'Error','text'=>$resultado['error']];
        header("Location: ../vista/asignacion_clase/asignacion_clase.php"); exit;
    }
}

### ELIMINAR
if(isset($_GET['E']) && $_GET['E']=="eli"){
    $id = base64_decode($_GET['I'] ?? '');
    if(!is_numeric($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'ID inválido.']; header("Location: ../vista/asignacion_clase/asignacion_clase.php"); exit; }
    $resultado = $claseObj->EliminarClase($id);
    $_SESSION['flash'] = $resultado['success']
        ? ['icon'=>'success','title'=>'Éxito','text'=>'Clase eliminada correctamente.']
        : ['icon'=>'error','title'=>'Error','text'=>$resultado['error']];
    header("Location: ../vista/asignacion_clase/asignacion_clase.php"); exit;
}
?>
