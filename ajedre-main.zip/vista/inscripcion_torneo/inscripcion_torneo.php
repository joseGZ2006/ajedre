<?php
session_start();
include("../../modelo/conexion.php");
include("../../modelo/clase_inscripcion_torneo.php");
// Verificar sesión antes de mostrar el dashboard
include_once("../../controlador/verificar_sesion.php");
$inscObj = new InscripcionTorneo();
$inscripciones = $inscObj->ListarInscripcionesTorneo();
// Función para obtener badge de estatus
function getEstatusBadge($estatus) {
    $clases = [
        'pendiente' => 'bg-warning text-dark',
        'confirmado' => 'bg-success',
        'rechazado' => 'bg-danger',
        'cancelado' => 'bg-secondary'
    ];
    return isset($clases[$estatus]) ? $clases[$estatus] : 'bg-secondary';
}
// Función para obtener badge de pago
function getPagoBadge($pago) {
    return $pago == 1 ? 'bg-success' : 'bg-danger';
}
function getPagoTexto($pago) {
    return $pago == 1 ? 'Pagado' : 'No Pagado';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include '../assets/inc/head.php'; ?>
</head>
<body>
<div class="page-container">
    <!-- SIDEBAR -->
    <?php include '../assets/inc/sidebar.php'; ?>
    <!-- HEADER -->
    <?php include '../assets/inc/header.php'; ?>
        <!-- MAIN CONTENT -->
        <div class="main-content">
            <div class="catalog-header">
                <h1 class="page-title"><i class="fas fa-trophy me-2"></i> INSCRIPCIONES A TORNEOS</h1>
                <a href="./insert_inscripcion_torneo.php" class="btn btn-custom"><i class="fas fa-plus-circle me-2"></i>Nueva Inscripción</a>
            </div>
            <!-- TABLA DE INSCRIPCIONES -->
            <div class="table-responsive">
                <table class="table alumno-table" id="inscripcionTorneoTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Alumno</th>
                            <th>Torneo</th>
                            <th>Fecha</th>
                            <th>Estado</th>
                            <th>Pago</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($inscripciones && count($inscripciones) > 0): ?>
                            <?php foreach($inscripciones as $row): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['idInscripcionTorneo']); ?></td>
                                <td><?php echo htmlspecialchars($row['nombre_alumno'] . ' ' . $row['apellido_alumno']); ?></td>
                                <td><?php echo htmlspecialchars($row['nombre_torneo']); ?></td>
                                <td><?php echo date('d/m/Y', strtotime($row['fecha'])); ?></td>
                                <td>
                                    <span class="badge <?php echo getEstatusBadge($row['estatus']); ?>">
                                        <?php echo ucfirst(htmlspecialchars($row['estatus'])); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge <?php echo getPagoBadge($row['pago']); ?>">
                                        <?php echo getPagoTexto($row['pago']); ?>
                                    </span>
                                </td>
                                <td>
                                    <!-- Ver detalle -->
                                    <a class="btn btn-sm btn-secondary" 
                                       href="../../controlador/ctl_inscripcion_torneo.php?C=con&I=<?php echo $row['idInscripcionTorneo']; ?>">
                                       <i class="fas fa-eye"></i>
                                    </a>
                                    <?php if($_SESSION['rol_ses'] == 'admin'){  ?>
                                    <!-- Editar -->
                                    <a class="btn btn-sm btn-primary" 
                                       href="../../controlador/ctl_inscripcion_torneo.php?M=mos&I=<?php echo $row['idInscripcionTorneo']; ?>">
                                       <i class="fas fa-edit"></i>
                                    </a>
                                    <!-- Eliminar -->
                                    <button class="btn btn-sm btn-danger btn-delete" 
                                            data-id="<?php echo base64_encode($row['idInscripcionTorneo']); ?>" 
                                            data-nombre="<?php echo htmlspecialchars($row['nombre_alumno'] . ' ' . $row['apellido_alumno']); ?>" 
                                            data-torneo="<?php echo htmlspecialchars($row['nombre_torneo']); ?>">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                    <?php } ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center">No hay inscripciones a torneos registradas</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php include '../assets/inc/flash.php'; ?>
    <script src="../assets/js/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/sidebar.js"></script>
    <script src="../assets/js/sweetalert2.all.min.js"></script>
    <script>
        function confirmarEliminacion(nombreAlumno, torneo, idBase64) {
            Swal.fire({
                title: '¿Eliminar inscripción?',
                text: `¿Estás seguro de que deseas eliminar la inscripción de ${nombreAlumno} al torneo "${torneo}"?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Sí, eliminar',
                cancelButtonText: 'Cancelar',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `../../controlador/ctl_inscripcion_torneo.php?E=eli&I=${idBase64}`;
                }
            });
        }
        document.addEventListener('DOMContentLoaded', function() {
            const botonesEliminar = document.querySelectorAll('.btn-delete');
            botonesEliminar.forEach((boton) => {
                boton.addEventListener('click', function(e) {
                    e.preventDefault();
                    const nombre = this.getAttribute('data-nombre');
                    const torneo = this.getAttribute('data-torneo');
                    const idBase64 = this.getAttribute('data-id');
                    confirmarEliminacion(nombre, torneo, idBase64);
                });
            });
        });
    </script>
</body>
</html>