<?php
session_start();
include("../modelo/conexion.php");
include("../modelo/clase_asistencia_entrenador.php");

$asistObj = new AsistenciaEntrenador();

### REGISTRAR
if(isset($_POST['registrar']) && $_POST['registrar']=="registrar"){
    $idEntrenador     = $_POST['idEntrenador']     ?? '';
    $fecha            = $_POST['fecha']            ?? '';
    $horaEntrada      = $_POST['horaEntrada']      ?? '';
    $horaSalida       = $_POST['horaSalida']       ?? '';
    $alumnosEntrenados= $_POST['alumnosEntrenados']?? '';
    $observacion      = $_POST['observacion']      ?? '';

    if (!empty($horaEntrada)) {
        $horaEntrada = date("H:i:s", strtotime($horaEntrada));
    }
    if (!empty($horaSalida)) {
        $horaSalida = date("H:i:s", strtotime($horaSalida));
    }

    $resultado = $asistObj->RegistrarAsistenciaEntrenador($idEntrenador, $fecha, $horaEntrada, $horaSalida, $alumnosEntrenados, $observacion);
    if($resultado['success']){
        $_SESSION['flash'] = ['icon'=>'success','title'=>'Éxito','text'=>'Asistencia de entrenador registrada.'];
        header("Location: ../vista/asistencias/asistencia.php"); exit;
    } else {
        $_SESSION['flash'] = ['icon'=>'error','title'=>'Error','text'=>$resultado['error']];
        header("Location: ../vista/asistencias/insert_asistenciaentrenador.php"); exit;
    }
}

### CONSULTAR
if(isset($_GET['C']) && $_GET['C']=="con"){
    $id = $_GET['I'] ?? '';
    if(!is_numeric($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'ID inválido.']; header("Location: ../vista/asistencias/asistencia.php"); exit; }
    $datos = $asistObj->ConsultarAsistenciaEntrenador($id);
    if(!$datos){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'Registro no encontrado.']; header("Location: ../vista/asistencias/asistencia.php"); exit; }
    $p = [
        'id'          => base64_encode($datos['idAsistenciaEntrenador']),
        'entrenador'  => base64_encode($datos['nombre_entrenador'].' '.$datos['apellido_entrenador']),
        'cedula'      => base64_encode($datos['cedula_entrenador'] ?? ''),
        'telefono'    => base64_encode($datos['telefono_entrenador'] ?? ''),
        'fecha'       => base64_encode($datos['fecha']),
        'entrada'     => base64_encode($datos['horaEntrada'] ?? ''),
        'salida'      => base64_encode($datos['horaSalida'] ?? ''),
        'alumnos'     => base64_encode($datos['alumnosEntrenados'] ?? ''),
        'obs'         => base64_encode($datos['observacion'] ?? ''),
    ];
    header("Location: ../vista/asistencias/detalle_asistenciaentrenador.php?" . http_build_query($p)); exit;
}

### MOSTRAR (editar)
if(isset($_GET['M']) && $_GET['M']=="mos"){
    $id = $_GET['I'] ?? '';
    if(!is_numeric($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'ID inválido.']; header("Location: ../vista/asistencias/asistencia.php"); exit; }
    $datos = $asistObj->ConsultarAsistenciaEntrenador($id);
    if(!$datos){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'Registro no encontrado.']; header("Location: ../vista/asistencias/asistencia.php"); exit; }
    $p = [
        'id'           => base64_encode($datos['idAsistenciaEntrenador']),
        'idEntrenador' => base64_encode($datos['idEntrenador']),
        'fecha'        => base64_encode($datos['fecha']),
        'entrada'      => base64_encode($datos['horaEntrada'] ?? ''),
        'salida'       => base64_encode($datos['horaSalida'] ?? ''),
        'alumnos'      => base64_encode($datos['alumnosEntrenados'] ?? ''),
        'obs'          => base64_encode($datos['observacion'] ?? ''),
    ];
    header("Location: ../vista/asistencias/edit_asistenciaentrenador.php?" . http_build_query($p)); exit;
}

### ACTUALIZAR
if(isset($_POST['actualizar']) && $_POST['actualizar']=="actualizar"){
    $id               = base64_decode($_POST['id'] ?? '');
    $idEntrenador     = $_POST['idEntrenador']      ?? '';
    $fecha            = $_POST['fecha']             ?? '';
    $horaEntrada      = $_POST['horaEntrada']       ?? '';
    $horaSalida       = $_POST['horaSalida']        ?? '';
    $alumnosEntrenados= $_POST['alumnosEntrenados'] ?? '';
    $observacion      = $_POST['observacion']       ?? '';

    if (!empty($horaEntrada)) {
        $horaEntrada = date("H:i:s", strtotime($horaEntrada));
    }
    if (!empty($horaSalida)) {
        $horaSalida = date("H:i:s", strtotime($horaSalida));
    }

    $resultado = $asistObj->ActualizarAsistenciaEntrenador($id, $idEntrenador, $fecha, $horaEntrada, $horaSalida, $alumnosEntrenados, $observacion);
    if($resultado['success']){
        $_SESSION['flash'] = ['icon'=>'success','title'=>'Éxito','text'=>'Asistencia actualizada.'];
        header("Location: ../vista/asistencias/asistencia.php"); exit;
    } else {
        $_SESSION['flash'] = ['icon'=>'error','title'=>'Error','text'=>$resultado['error']];
        header("Location: ../vista/asistencias/asistencia.php"); exit;
    }
}

### ELIMINAR
if(isset($_GET['E']) && $_GET['E']=="eli"){
    $id = base64_decode($_GET['I'] ?? '');
    if(!is_numeric($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'ID inválido.']; header("Location: ../vista/asistencias/asistencia.php"); exit; }
    $resultado = $asistObj->EliminarAsistenciaEntrenador($id);
    $_SESSION['flash'] = $resultado['success']
        ? ['icon'=>'success','title'=>'Éxito','text'=>'Asistencia eliminada.']
        : ['icon'=>'error','title'=>'Error','text'=>$resultado['error']];
    header("Location: ../vista/asistencias/asistencia.php"); exit;
}
?>
