<?php
// Clase InscripcionAlumno
class InscripcionAlumno {
    // DECLARACION DE LAS PROPIEDADES
    public $idInscripcionAlumno, $idAlumno, $fecha, $estatus;

    // Setters
    public function setIdInscripcionAlumno($idInscripcionAlumno){ $this->idInscripcionAlumno = $idInscripcionAlumno; }
    public function setIdAlumno($idAlumno){ $this->idAlumno = $idAlumno; }
    public function setFecha($fecha){ $this->fecha = $fecha; }
    public function setEstatus($estatus){ $this->estatus = $estatus; }

    // Getters
    public function getIdInscripcionAlumno(){ return $this->idInscripcionAlumno; }
    public function getIdAlumno(){ return $this->idAlumno; }
    public function getFecha(){ return $this->fecha; }
    public function getEstatus(){ return $this->estatus; }

    // Función privada para validar fecha
    private function validarFecha($fecha) {
        if(empty($fecha)) {
            return false;
        }
        $fechaObj = DateTime::createFromFormat('Y-m-d', $fecha);
        return $fechaObj && $fechaObj->format('Y-m-d') === $fecha;
    }

    // Función privada para validar estatus
    private function validarEstatus($estatus) {
        $estatusPermitidos = ['activo', 'inactivo', 'suspendido'];
        return in_array($estatus, $estatusPermitidos);
    }

    // Verificar si el alumno ya tiene una inscripción activa/vigente o existente
    public function verificarInscripcionExistente($idAlumno, $excluirId = null) {
        include("conexion.php");
        
        try {
            if($excluirId) {
                $sql = $conex->prepare("SELECT COUNT(*) as total FROM INSCRIPCION_ALUMNO WHERE idAlumno = ? AND idInscripcionAlumno != ?");
                $sql->execute([$idAlumno, $excluirId]);
            } else {
                $sql = $conex->prepare("SELECT COUNT(*) as total FROM INSCRIPCION_ALUMNO WHERE idAlumno = ?");
                $sql->execute([$idAlumno]);
            }
            
            $resultado = $sql->fetch(PDO::FETCH_ASSOC);
            return $resultado['total'] > 0;
        } catch (PDOException $e) {
            error_log("Error verificarInscripcionExistente: " . $e->getMessage());
            return false;
        }
    }

    ############################################################################
    ### REGISTRAR ##############################################################
    ############################################################################
    public function RegistrarInscripcionAlumno($idAlumno, $fecha, $estatus){
        include("conexion.php");
        
        // Validaciones
        if(empty($idAlumno) || !is_numeric($idAlumno)) {
            return ['success' => false, 'error' => 'Alumno inválido o no seleccionado.'];
        }
        if(!$this->validarFecha($fecha)) {
            return ['success' => false, 'error' => 'La fecha de inscripción no es válida.'];
        }
        if(!$this->validarEstatus($estatus)) {
            return ['success' => false, 'error' => 'El estatus no es válido.'];
        }
        
        // Verificar inscripción duplicada
        if($this->verificarInscripcionExistente($idAlumno)) {
            return ['success' => false, 'error' => 'El alumno ya tiene una inscripción registrada en el sistema.'];
        }

        try {
            // Verificar si el alumno existe
            $sqlAlumno = $conex->prepare("SELECT idAlumno FROM ALUMNO WHERE idAlumno = ?");
            $sqlAlumno->execute([$idAlumno]);
            if(!$sqlAlumno->fetch()) {
                return ['success' => false, 'error' => 'El alumno seleccionado no existe.'];
            }

            // Insertar nueva inscripción
            $sql = $conex->prepare("INSERT INTO INSCRIPCION_ALUMNO (idAlumno, fecha, estatus) VALUES (?, ?, ?)");
            $insertar = $sql->execute([$idAlumno, $fecha, $estatus]);
            
            if($insertar) {
                return ['success' => true];
            } else {
                return ['success' => false, 'error' => 'Error al registrar la inscripción en la base de datos.'];
            }
        } catch (PDOException $e) {
            error_log("Error al registrar inscripcion_alumno: " . $e->getMessage());
            return ['success' => false, 'error' => 'Error en la base de datos al realizar el registro.'];
        }
    }

    #############################################################################
    ### LISTAR ##################################################################
    #############################################################################
    public function ListarInscripcionesAlumno(){
        include("conexion.php");
        
        try {
            $sql = $conex->prepare("SELECT ia.*, 
                                           a.nombre as nombre_alumno, a.apellido as apellido_alumno, a.cedula as cedula_alumno, a.club as club_alumno
                                    FROM INSCRIPCION_ALUMNO ia 
                                    INNER JOIN ALUMNO a ON ia.idAlumno = a.idAlumno
                                    ORDER BY ia.idInscripcionAlumno DESC");
            $sql->execute();
            $num_reg = $sql->rowCount();
            if ($num_reg > 0) {
                return $sql->fetchAll(PDO::FETCH_ASSOC);
            }
            return false;
        } catch (PDOException $e) {
            error_log("Error al listar inscripciones de alumnos: " . $e->getMessage());
            return false;
        }
    }

    #############################################################################
    ### CONSULTAR POR ID ########################################################
    #############################################################################
    public function ConsultarInscripcionAlumno($idInscripcionAlumno){
        include("conexion.php");
        
        try {
            $sql = $conex->prepare("SELECT ia.*, 
                                           a.nombre as nombre_alumno, a.apellido as apellido_alumno, a.cedula as cedula_alumno, a.club as club_alumno, a.correo as correo_alumno, a.telefono as telefono_alumno
                                    FROM INSCRIPCION_ALUMNO ia 
                                    INNER JOIN ALUMNO a ON ia.idAlumno = a.idAlumno
                                    WHERE ia.idInscripcionAlumno = ?");
            $sql->execute([$idInscripcionAlumno]);
            $num_reg = $sql->rowCount();
            if ($num_reg > 0) {
                return $sql->fetch(PDO::FETCH_ASSOC);  
            }
            return false;
        } catch (PDOException $e) {
            error_log("Error al consultar inscripcion de alumno por ID: " . $e->getMessage());
            return false;
        }
    }
    
    ############################################################################
    ### MOSTRAR ################################################################
    ############################################################################
    public function MostrarInscripcionAlumno($idInscripcionAlumno){
        include("conexion.php");
        
        try {
            $sql = $conex->prepare("SELECT ia.*, 
                                           a.nombre as nombre_alumno, a.apellido as apellido_alumno
                                    FROM INSCRIPCION_ALUMNO ia 
                                    INNER JOIN ALUMNO a ON ia.idAlumno = a.idAlumno
                                    WHERE ia.idInscripcionAlumno = ?");
            $sql->execute([$idInscripcionAlumno]);
            $num_reg = $sql->rowCount();
            
            if ($num_reg > 0) {
                return $sql->fetch(PDO::FETCH_ASSOC);  
            }
            return false;
        } catch (PDOException $e) {
            error_log("Error al mostrar inscripcion de alumno por ID: " . $e->getMessage());
            return false;
        }
    }

    #############################################################################
    ### ACTUALIZAR ##############################################################
    #############################################################################
    public function ActualizarInscripcionAlumno($idInscripcionAlumno, $idAlumno, $fecha, $estatus){
        include("conexion.php"); 
        
        // Validaciones
        if(empty($idAlumno) || !is_numeric($idAlumno)) {
            return ['success' => false, 'error' => 'Alumno inválido o no seleccionado.'];
        }
        if(!$this->validarFecha($fecha)) {
            return ['success' => false, 'error' => 'La fecha de inscripción no es válida.'];
        }
        if(!$this->validarEstatus($estatus)) {
            return ['success' => false, 'error' => 'El estatus no es válido.'];
        }
        
        // Verificar inscripción duplicada
        if($this->verificarInscripcionExistente($idAlumno, $idInscripcionAlumno)) {
            return ['success' => false, 'error' => 'El alumno ya tiene otra inscripción registrada en el sistema.'];
        }

        try {
            // Verificar si el alumno existe
            $sqlAlumno = $conex->prepare("SELECT idAlumno FROM ALUMNO WHERE idAlumno = ?");
            $sqlAlumno->execute([$idAlumno]);
            if(!$sqlAlumno->fetch()) {
                return ['success' => false, 'error' => 'El alumno seleccionado no existe.'];
            }

            // Actualizar
            $sql = $conex->prepare("UPDATE INSCRIPCION_ALUMNO SET idAlumno = ?, fecha = ?, estatus = ? WHERE idInscripcionAlumno = ?");
            $actualizar = $sql->execute([$idAlumno, $fecha, $estatus, $idInscripcionAlumno]);
            
            if($actualizar) {
                return ['success' => true];
            } else {
                return ['success' => false, 'error' => 'Error al actualizar la inscripción en la base de datos.'];
            }
        } catch (PDOException $e) {
            error_log("Error al actualizar inscripcion_alumno: " . $e->getMessage());
            return ['success' => false, 'error' => 'Error en la base de datos al actualizar el registro.'];
        }
    }

    ############################################################################
    ### ELIMINAR ###############################################################
    ############################################################################
    public function EliminarInscripcionAlumno($idInscripcionAlumno){
        include("conexion.php"); 
        
        try {
            $conex->beginTransaction();
            
            // Verificar si existe la inscripción
            $sql = $conex->prepare("SELECT idInscripcionAlumno FROM INSCRIPCION_ALUMNO WHERE idInscripcionAlumno = ?");
            $sql->execute([$idInscripcionAlumno]);
            $insc = $sql->fetch(PDO::FETCH_ASSOC);
            
            if(!$insc) {
                $conex->rollBack();
                return ['success' => false, 'error' => 'La inscripción de alumno no existe.'];
            }
            
            // Eliminar la inscripción
            $sql = $conex->prepare("DELETE FROM INSCRIPCION_ALUMNO WHERE idInscripcionAlumno = ?");
            $eliminar = $sql->execute([$idInscripcionAlumno]);
            
            if($eliminar) {
                $conex->commit();
                return ['success' => true];
            } else {
                $conex->rollBack();
                return ['success' => false, 'error' => 'Error al eliminar la inscripción.'];
            }
            
        } catch (Exception $e) {
            if($conex->inTransaction()) $conex->rollBack();
            error_log("Error al eliminar inscripcion_alumno: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    ############################################################################
    ### CAMBIAR ESTATUS ########################################################
    ############################################################################
    public function CambiarEstatusInscripcionAlumno($idInscripcionAlumno, $nuevoEstatus){
        include("conexion.php");

        $estatusPermitidos = ['activo', 'inactivo', 'suspendido'];
        if (!in_array($nuevoEstatus, $estatusPermitidos)) {
            return ['success' => false, 'error' => 'Estatus no válido.'];
        }

        try {
            $sql = $conex->prepare("UPDATE INSCRIPCION_ALUMNO SET estatus = ? WHERE idInscripcionAlumno = ?");
            $ok  = $sql->execute([$nuevoEstatus, $idInscripcionAlumno]);

            if ($ok) {
                return ['success' => true, 'estatus' => $nuevoEstatus];
            } else {
                return ['success' => false, 'error' => 'No se pudo actualizar el estatus.'];
            }
        } catch (PDOException $e) {
            error_log("Error CambiarEstatusInscripcionAlumno: " . $e->getMessage());
            return ['success' => false, 'error' => 'Error en la base de datos.'];
        }
    }
}
?>
