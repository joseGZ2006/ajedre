<?php
session_start();
include("../../modelo/conexion.php");
include("../../modelo/clase_inscripcion_alumno.php");
// Verificar sesión antes de mostrar el dashboard
include_once("../../controlador/verificar_sesion.php");

$inscripcionObj = new InscripcionAlumno();
$inscripciones = $inscripcionObj->ListarInscripcionesAlumno();

function getEstatusBadge($estatus) {
    $clases = [
        'activo'     => 'bg-success',
        'inactivo'   => 'bg-danger',
        'suspendido' => 'bg-warning text-dark',
    ];
    return isset($clases[$estatus]) ? $clases[$estatus] : 'bg-secondary';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include '../assets/inc/head.php'; ?>
  
</head>

<body>
<div class="page-container">

    <!-- SIDEBAR -->
    <?php include '../assets/inc/sidebar.php'; ?>

    <!-- HEADER -->
    <?php include '../assets/inc/header.php'; ?>

        <!-- MAIN CONTENT -->
        <div class="main-content">
            <div class="catalog-header">
                <h1 class="page-title"><i class="fas fa-user-plus me-2"></i> INSCRIPCIONES DE ALUMNOS</h1>
                <a href="./insert_inscripcion_alumno.php" class="btn btn-custom"><i class="fas fa-plus-circle me-2"></i>Nueva Inscripción</a>
            </div>

            <!-- TABLA DE INSCRIPCIONES -->
            <div class="table-responsive">
                <table class="table alumno-table" id="inscripcionAlumnoTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Alumno</th>
                            <th>Fecha</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($inscripciones && count($inscripciones) > 0): ?>
                            <?php foreach($inscripciones as $row): ?>
                            <tr id="fila-<?php echo $row['idInscripcionAlumno']; ?>">
                                <td><?php echo htmlspecialchars($row['idInscripcionAlumno']); ?></td>
                                <td><?php echo htmlspecialchars($row['nombre_alumno'] . ' ' . $row['apellido_alumno']); ?></td>
                                <td><?php echo date('d/m/Y', strtotime($row['fecha'])); ?></td>
                                <td>
                                    <?php
                                        $esActivo = ($row['estatus'] === 'activo');
                                        $id       = $row['idInscripcionAlumno'];
                                        $estatus  = htmlspecialchars($row['estatus']);
                                    ?>
                                    <div class="switch-wrap">
                                        <label class="switch" title="Cambiar a <?php echo $esActivo ? 'Suspendido' : 'Activo'; ?>">
                                            <input type="checkbox"
                                                   class="toggle-estatus"
                                                   data-id="<?php echo $id; ?>"
                                                   data-estatus="<?php echo $estatus; ?>"
                                                   <?php echo $esActivo ? 'checked' : ''; ?>>
                                            <span class="slider"></span>
                                        </label>
                                        <span class="switch-label badge <?php echo getEstatusBadge($row['estatus']); ?>"
                                              id="badge-<?php echo $id; ?>">
                                            <?php echo ucfirst($estatus); ?>
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <!-- Ver detalle -->
                                    <a class="btn btn-sm btn-secondary"
                                       href="../../controlador/ctl_inscripcion_alumno.php?C=con&I=<?php echo $id; ?>">
                                       <i class="fas fa-eye"></i>
                                    </a>
                                   <?php if($_SESSION['rol_ses'] == 'admin'){  ?> 
                                 
                                    <!-- Eliminar -->
                                    <button class="btn btn-sm btn-danger btn-delete"
                                            data-id="<?php echo base64_encode($id); ?>"
                                            data-nombre="<?php echo htmlspecialchars($row['nombre_alumno'] . ' ' . $row['apellido_alumno']); ?>">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                    <?php }  ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">No hay inscripciones de alumnos registradas</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php include '../assets/inc/flash.php'; ?>
    <script src="../assets/js/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/sidebar.js"></script>
    <script src="../assets/js/sweetalert2.all.min.js"></script>
    <script>
    /* ── Toggle de estatus ── */
    document.querySelectorAll('.toggle-estatus').forEach(function(toggle) {
        toggle.addEventListener('change', function() {
            const checkbox   = this;
            const id         = checkbox.getAttribute('data-id');
            const estatusAct = checkbox.getAttribute('data-estatus');
            const badge      = document.getElementById('badge-' + id);
            const nuevoLabel = checkbox.checked ? 'Activo' : 'Suspendido';

            // Confirmación antes de cambiar
            Swal.fire({
                title: '¿Cambiar estatus?',
                text: `Se cambiará el estatus a "${nuevoLabel}"`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#27ae60',
                cancelButtonColor: '#e74c3c',
                confirmButtonText: 'Sí, cambiar',
                cancelButtonText: 'Cancelar'
            }).then(function(result) {
                if (result.isConfirmed) {
                    const formData = new FormData();
                    formData.append('T', 'tog');
                    formData.append('id', id);
                    formData.append('estatus', estatusAct);

                    fetch('../../controlador/ctl_inscripcion_alumno.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.success) {
                            const nuevo = data.estatus;
                            // Actualizar atributo para futuras llamadas
                            checkbox.setAttribute('data-estatus', nuevo);

                            // Actualizar badge
                            badge.textContent = nuevo.charAt(0).toUpperCase() + nuevo.slice(1);
                            badge.className = 'switch-label badge ' + (nuevo === 'activo' ? 'bg-success' : 'bg-warning text-dark');

                            Swal.fire({
                                icon: 'success',
                                title: 'Estatus actualizado',
                                text: `Estatus cambiado a "${nuevo}"`,
                                timer: 1800,
                                showConfirmButton: false
                            });
                        } else {
                            // Revertir el toggle visualmente
                            checkbox.checked = !checkbox.checked;
                            Swal.fire({ icon: 'error', title: 'Error', text: data.error || 'No se pudo actualizar.' });
                        }
                    })
                    .catch(function() {
                        checkbox.checked = !checkbox.checked;
                        Swal.fire({ icon: 'error', title: 'Error de red', text: 'No se pudo conectar con el servidor.' });
                    });
                } else {
                    // Canceló: revertir el toggle
                    checkbox.checked = !checkbox.checked;
                }
            });
        });
    });

    /* ── Eliminar ── */
    function confirmarEliminacion(nombreAlumno, idBase64) {
        Swal.fire({
            title: '¿Eliminar inscripción?',
            text: `¿Estás seguro de que deseas eliminar la inscripción del alumno ${nombreAlumno}?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar',
            reverseButtons: true
        }).then(function(result) {
            if (result.isConfirmed) {
                window.location.href = `../../controlador/ctl_inscripcion_alumno.php?E=eli&I=${idBase64}`;
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.btn-delete').forEach(function(boton) {
            boton.addEventListener('click', function(e) {
                e.preventDefault();
                const nombre   = this.getAttribute('data-nombre');
                const idBase64 = this.getAttribute('data-id');
                confirmarEliminacion(nombre, idBase64);
            });
        });
    });
    </script>
</body>
</html>