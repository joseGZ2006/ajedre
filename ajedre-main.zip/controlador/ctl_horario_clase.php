<?php
session_start();
include("../modelo/conexion.php");
include("../modelo/clase_horario_clase.php");

$horario = new HorarioClase();

### REGISTRAR
if(isset($_POST['registrar']) && $_POST['registrar'] == "registrar"){
    $diaSemana  = $_POST['diaSemana']  ?? '';
    $horaInicio = $_POST['horaInicio'] ?? '';
    $horaFin    = $_POST['horaFin']    ?? '';

    $resultado = $horario->RegistrarHorarioClase($diaSemana, $horaInicio, $horaFin);
    if($resultado['success']){
        $_SESSION['flash'] = ['icon'=>'success','title'=>'Éxito','text'=>'Horario registrado correctamente.'];
        header("Location: ../vista/horarios/horario.php"); exit;
    } else {
        $_SESSION['flash'] = ['icon'=>'error','title'=>'Error','text'=>$resultado['error']];
        header("Location: ../vista/horarios/insert_horario.php"); exit;
    }
}

### LISTAR
if(isset($_GET['L']) && $_GET['L']=="lis"){
    header("Location: ../vista/horarios/horario.php"); exit;
}

### CONSULTAR (detalle)
if(isset($_GET['C']) && $_GET['C']=="con"){
    $id = $_GET['I'] ?? '';
    if(!is_numeric($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'ID inválido.']; header("Location: ../vista/horarios/horario.php"); exit; }
    $datos = $horario->ConsultarHorarioClase($id);
    if(!$datos){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'Horario no encontrado.']; header("Location: ../vista/horarios/horario.php"); exit; }
    $idE  = base64_encode($datos['idHorarioClase']);
    $diaE = base64_encode($datos['diaSemana']);
    $hiE  = base64_encode($datos['horaInicio']);
    $hfE  = base64_encode($datos['horaFin']);
    header("Location: ../vista/horarios/detalle_horario.php?id=$idE&dia=$diaE&hi=$hiE&hf=$hfE"); exit;
}

### MOSTRAR (editar)
if(isset($_GET['M']) && $_GET['M']=="mos"){
    $id = $_GET['I'] ?? '';
    if(!is_numeric($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'ID inválido.']; header("Location: ../vista/horarios/horario.php"); exit; }
    $datos = $horario->ConsultarHorarioClase($id);
    if(!$datos){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'Horario no encontrado.']; header("Location: ../vista/horarios/horario.php"); exit; }
    $idE  = base64_encode($datos['idHorarioClase']);
    $diaE = base64_encode($datos['diaSemana']);
    $hiE  = base64_encode($datos['horaInicio']);
    $hfE  = base64_encode($datos['horaFin']);
    header("Location: ../vista/horarios/edit_horario.php?id=$idE&dia=$diaE&hi=$hiE&hf=$hfE"); exit;
}

### ACTUALIZAR
if(isset($_POST['actualizar']) && $_POST['actualizar']=="actualizar"){
    $id         = base64_decode($_POST['id'] ?? '');
    $diaSemana  = $_POST['diaSemana']  ?? '';
    $horaInicio = $_POST['horaInicio'] ?? '';
    $horaFin    = $_POST['horaFin']    ?? '';

    $resultado = $horario->ActualizarHorarioClase($id, $diaSemana, $horaInicio, $horaFin);
    if($resultado['success']){
        $_SESSION['flash'] = ['icon'=>'success','title'=>'Éxito','text'=>'Horario actualizado correctamente.'];
        header("Location: ../vista/horarios/horario.php"); exit;
    } else {
        $_SESSION['flash'] = ['icon'=>'error','title'=>'Error','text'=>$resultado['error']];
        header("Location: ../vista/horarios/edit_horario.php?id={$_POST['id']}&dia={$_POST['dia_original']}&hi={$_POST['hi_original']}&hf={$_POST['hf_original']}"); exit;
    }
}

### ELIMINAR
if(isset($_GET['E']) && $_GET['E']=="eli"){
    $id = base64_decode($_GET['I'] ?? '');
    if(!is_numeric($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'ID inválido.']; header("Location: ../vista/horarios/horario.php"); exit; }
    $resultado = $horario->EliminarHorarioClase($id);
    if($resultado['success']){
        $_SESSION['flash'] = ['icon'=>'success','title'=>'Éxito','text'=>'Horario eliminado correctamente.'];
    } else {
        $_SESSION['flash'] = ['icon'=>'error','title'=>'Error','text'=>$resultado['error']];
    }
    header("Location: ../vista/horarios/horario.php"); exit;
}
?>
