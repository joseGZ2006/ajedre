<?php
// Clase InscripcionTorneo
class InscripcionTorneo {
    // DECLARACION DE LAS PROPIEDADES
    public $idInscripcionTorneo, $idAlumno, $idTorneo, $fecha, $estatus, $pago;
    // Setters
    public function setIdInscripcionTorneo($idInscripcionTorneo){ $this->idInscripcionTorneo = $idInscripcionTorneo; }
    public function setIdAlumno($idAlumno){ $this->idAlumno = $idAlumno; }
    public function setIdTorneo($idTorneo){ $this->idTorneo = $idTorneo; }
    public function setFecha($fecha){ $this->fecha = $fecha; }
    public function setEstatus($estatus){ $this->estatus = $estatus; }
    public function setPago($pago){ $this->pago = $pago; }
     
    // Getters
    public function getIdInscripcionTorneo(){ return $this->idInscripcionTorneo; }
    public function getIdAlumno(){ return $this->idAlumno; }
    public function getIdTorneo(){ return $this->idTorneo; }
    public function getFecha(){ return $this->fecha; }
    public function getEstatus(){ return $this->estatus; }
    public function getPago(){ return $this->pago; }
    // Función privada para validar fecha
    private function validarFecha($fecha) {
        if(empty($fecha)) {
            return false;
        }
        $fechaObj = DateTime::createFromFormat('Y-m-d', $fecha);
        return $fechaObj && $fechaObj->format('Y-m-d') === $fecha;
    }
    // Función privada para validar estatus
    private function validarEstatus($estatus) {
        $estatusPermitidos = ['pendiente', 'confirmado', 'rechazado', 'cancelado'];
        return in_array($estatus, $estatusPermitidos);
    }
    // Función privada para validar pago
    private function validarPago($pago) {
        return $pago == 0 || $pago == 1;
    }
    // Verificar si el alumno ya está inscrito en el torneo
    public function verificarInscripcionExistente($idAlumno, $idTorneo, $excluirId = null) {
        include("conexion.php");
        
        try {
            if($excluirId) {
                $sql = $conex->prepare("SELECT COUNT(*) as total FROM INSCRIPCION_TORNEO WHERE idAlumno = ? AND idTorneo = ? AND idInscripcionTorneo != ?");
                $sql->execute([$idAlumno, $idTorneo, $excluirId]);
            } else {
                $sql = $conex->prepare("SELECT COUNT(*) as total FROM INSCRIPCION_TORNEO WHERE idAlumno = ? AND idTorneo = ?");
                $sql->execute([$idAlumno, $idTorneo]);
            }
            
            $resultado = $sql->fetch(PDO::FETCH_ASSOC);
            return $resultado['total'] > 0;
        } catch (PDOException $e) {
            error_log("Error verificarInscripcionExistente: " . $e->getMessage());
            return false;
        }
    }
    ############################################################################
    ### REGISTRAR ##############################################################
    ############################################################################
    public function RegistrarInscripcionTorneo($idAlumno, $idTorneo, $fecha, $estatus, $pago){
        include("conexion.php");
        // Validaciones
        if(empty($idAlumno) || !is_numeric($idAlumno)) {
            return ['success' => false, 'error' => 'Alumno inválido o no seleccionado.'];
        }
        if(empty($idTorneo) || !is_numeric($idTorneo)) {
            return ['success' => false, 'error' => 'Torneo inválido o no seleccionado.'];
        }
        if(!$this->validarFecha($fecha)) {
            return ['success' => false, 'error' => 'La fecha de inscripción no es válida.'];
        }
        if(!$this->validarEstatus($estatus)) {
            return ['success' => false, 'error' => 'El estatus no es válido.'];
        }
        if(!$this->validarPago($pago)) {
            return ['success' => false, 'error' => 'El estado de pago no es válido.'];
        }
        
        // Verificar inscripción duplicada
        if($this->verificarInscripcionExistente($idAlumno, $idTorneo)) {
            return ['success' => false, 'error' => 'El alumno ya está inscrito en este torneo.'];
        }
        try {
            // Verificar si hay cupo disponible en el torneo
            $sqlTorneo = $conex->prepare("SELECT cupo FROM TORNEO WHERE idTorneo = ?");
            $sqlTorneo->execute([$idTorneo]);
            $torneo = $sqlTorneo->fetch(PDO::FETCH_ASSOC);
            
            if (!$torneo) {
                return ['success' => false, 'error' => 'El torneo seleccionado no existe.'];
            }
            
            $sqlInscritos = $conex->prepare("SELECT COUNT(*) as total FROM INSCRIPCION_TORNEO WHERE idTorneo = ? AND estatus != 'cancelado'");
            $sqlInscritos->execute([$idTorneo]);
            $inscritos = $sqlInscritos->fetch(PDO::FETCH_ASSOC);
            
            if ($inscritos['total'] >= $torneo['cupo']) {
                return ['success' => false, 'error' => 'No hay cupos disponibles para este torneo.'];
            }
            // Insertar nueva inscripción
            $sql = $conex->prepare("INSERT INTO INSCRIPCION_TORNEO (idAlumno, idTorneo, fecha, estatus, pago) VALUES (?, ?, ?, ?, ?)");
            $insertar = $sql->execute([$idAlumno, $idTorneo, $fecha, $estatus, $pago]);
            
            if($insertar) {
                return ['success' => true];
            } else {
                return ['success' => false, 'error' => 'Error al registrar la inscripción en la base de datos.'];
            }
        } catch (PDOException $e) {
            error_log("Error al registrar inscripcion_torneo: " . $e->getMessage());
            return ['success' => false, 'error' => 'Error en la base de datos al realizar el registro.'];
        }
    }
    #############################################################################
    ### LISTAR ##################################################################
    #############################################################################
    public function ListarInscripcionesTorneo(){
        include("conexion.php");
        
        try {
            $sql = $conex->prepare("SELECT it.*, 
                                           a.nombre as nombre_alumno, a.apellido as apellido_alumno, a.cedula as cedula_alumno,
                                           t.nombre as nombre_torneo, t.fecha as fecha_torneo
                                    FROM INSCRIPCION_TORNEO it 
                                    INNER JOIN ALUMNO a ON it.idAlumno = a.idAlumno
                                    INNER JOIN TORNEO t ON it.idTorneo = t.idTorneo
                                    ORDER BY it.idInscripcionTorneo DESC");
            $sql->execute();
            $num_reg = $sql->rowCount();
            if ($num_reg > 0) {
                return $sql->fetchAll(PDO::FETCH_ASSOC);
            }
            return false;
        } catch (PDOException $e) {
            error_log("Error al listar inscripciones de torneos: " . $e->getMessage());
            return false;
        }
    }
    #############################################################################
    ### CONSULTAR POR ID ########################################################
    #############################################################################
    public function ConsultarInscripcionTorneo($idInscripcionTorneo){
        include("conexion.php");
        
        try {
            $sql = $conex->prepare("SELECT it.*, 
                                           a.nombre as nombre_alumno, a.apellido as apellido_alumno, a.cedula as cedula_alumno, a.categoria as categoria_alumno,
                                           t.nombre as nombre_torneo, t.fecha as fecha_torneo, t.lugar as lugar_torneo
                                    FROM INSCRIPCION_TORNEO it 
                                    INNER JOIN ALUMNO a ON it.idAlumno = a.idAlumno
                                    INNER JOIN TORNEO t ON it.idTorneo = t.idTorneo
                                    WHERE it.idInscripcionTorneo = ?");
            $sql->execute([$idInscripcionTorneo]);
            $num_reg = $sql->rowCount();
            if ($num_reg > 0) {
                return $sql->fetch(PDO::FETCH_ASSOC);  
            }
            return false;
        } catch (PDOException $e) {
            error_log("Error al consultar inscripcion de torneo por ID: " . $e->getMessage());
            return false;
        }
    }
    
    ############################################################################
    ### MOSTRAR ################################################################
    ############################################################################
    public function MostrarInscripcionTorneo($idInscripcionTorneo){
        include("conexion.php");
        
        try {
            $sql = $conex->prepare("SELECT it.*, 
                                           a.nombre as nombre_alumno, a.apellido as apellido_alumno,
                                           t.nombre as nombre_torneo
                                    FROM INSCRIPCION_TORNEO it 
                                    INNER JOIN ALUMNO a ON it.idAlumno = a.idAlumno
                                    INNER JOIN TORNEO t ON it.idTorneo = t.idTorneo
                                    WHERE it.idInscripcionTorneo = ?");
            $sql->execute([$idInscripcionTorneo]);
            $num_reg = $sql->rowCount();
            
            if ($num_reg > 0) {
                return $sql->fetch(PDO::FETCH_ASSOC);  
            }
            return false;
        } catch (PDOException $e) {
            error_log("Error al mostrar inscripcion de torneo por ID: " . $e->getMessage());
            return false;
        }
    }
    #############################################################################
    ### ACTUALIZAR ##############################################################
    #############################################################################
    public function ActualizarInscripcionTorneo($idInscripcionTorneo, $idAlumno, $idTorneo, $fecha, $estatus, $pago){
        include("conexion.php"); 
        // Validaciones
        if(empty($idAlumno) || !is_numeric($idAlumno)) {
            return ['success' => false, 'error' => 'Alumno inválido o no seleccionado.'];
        }
        if(empty($idTorneo) || !is_numeric($idTorneo)) {
            return ['success' => false, 'error' => 'Torneo inválido o no seleccionado.'];
        }
        if(!$this->validarFecha($fecha)) {
            return ['success' => false, 'error' => 'La fecha de inscripción no es válida.'];
        }
        if(!$this->validarEstatus($estatus)) {
            return ['success' => false, 'error' => 'El estatus no es válido.'];
        }
        if(!$this->validarPago($pago)) {
            return ['success' => false, 'error' => 'El estado de pago no es válido.'];
        }
        // Verificar inscripción duplicada
        if($this->verificarInscripcionExistente($idAlumno, $idTorneo, $idInscripcionTorneo)) {
            return ['success' => false, 'error' => 'El alumno ya tiene otra inscripción registrada para este torneo.'];
        }
        try {
            // Si el estatus cambia a confirmado o pendiente (no cancelado), verificar cupos
            if ($estatus != 'cancelado') {
                $sqlTorneo = $conex->prepare("SELECT cupo FROM TORNEO WHERE idTorneo = ?");
                $sqlTorneo->execute([$idTorneo]);
                $torneo = $sqlTorneo->fetch(PDO::FETCH_ASSOC);
                
                if (!$torneo) {
                    return ['success' => false, 'error' => 'El torneo seleccionado no existe.'];
                }
                
                $sqlInscritos = $conex->prepare("SELECT COUNT(*) as total FROM INSCRIPCION_TORNEO WHERE idTorneo = ? AND estatus != 'cancelado' AND idInscripcionTorneo != ?");
                $sqlInscritos->execute([$idTorneo, $idInscripcionTorneo]);
                $inscritos = $sqlInscritos->fetch(PDO::FETCH_ASSOC);
                
                if ($inscritos['total'] >= $torneo['cupo']) {
                    return ['success' => false, 'error' => 'No hay cupos disponibles en el torneo para esta inscripción.'];
                }
            }
            // Actualizar
            $sql = $conex->prepare("UPDATE INSCRIPCION_TORNEO SET idAlumno = ?, idTorneo = ?, fecha = ?, estatus = ?, pago = ? WHERE idInscripcionTorneo = ?");
            $actualizar = $sql->execute([$idAlumno, $idTorneo, $fecha, $estatus, $pago, $idInscripcionTorneo]);
            
            if($actualizar) {
                return ['success' => true];
            } else {
                return ['success' => false, 'error' => 'Error al actualizar la inscripción en la base de datos.'];
            }
        } catch (PDOException $e) {
            error_log("Error al actualizar inscripcion_torneo: " . $e->getMessage());
            return ['success' => false, 'error' => 'Error en la base de datos al actualizar el registro.'];
        }
    }
    ############################################################################
    ### ELIMINAR ###############################################################
    ############################################################################
    public function EliminarInscripcionTorneo($idInscripcionTorneo){
        include("conexion.php"); 
        
        try {
            $conex->beginTransaction();
            
            // Verificar si existe la inscripción
            $sql = $conex->prepare("SELECT idInscripcionTorneo FROM INSCRIPCION_TORNEO WHERE idInscripcionTorneo = ?");
            $sql->execute([$idInscripcionTorneo]);
            $insc = $sql->fetch(PDO::FETCH_ASSOC);
            
            if(!$insc) {
                $conex->rollBack();
                return ['success' => false, 'error' => 'La inscripción de torneo no existe.'];
            }
            
            // Eliminar la inscripción
            $sql = $conex->prepare("DELETE FROM INSCRIPCION_TORNEO WHERE idInscripcionTorneo = ?");
            $eliminar = $sql->execute([$idInscripcionTorneo]);
            
            if($eliminar) {
                $conex->commit();
                return ['success' => true];
            } else {
                $conex->rollBack();
                return ['success' => false, 'error' => 'Error al eliminar la inscripción.'];
            }
            
        } catch (Exception $e) {
            if($conex->inTransaction()) $conex->rollBack();
            error_log("Error al eliminar inscripcion_torneo: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}
?>