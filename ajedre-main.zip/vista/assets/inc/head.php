    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Casa del Ajedrez - Detalle Asistencia Entrenador</title>

    <link rel="icon" type="image/jpeg" href="../assets/images/logo1.png">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="../assets/css/estyles.css">
    <link rel="stylesheet" href="../assets/css/general.css">
    <link rel="stylesheet" href="../assets/js/datatables/datatables.min.css">
    <style>
         /* ── Toggle switch deslizante ── */
        .switch-wrap {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .switch {
            position: relative;
            display: inline-block;
            width: 46px;
            height: 24px;
            flex-shrink: 0;
        }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider {
            position: absolute;
            cursor: pointer;
            inset: 0;
            background-color: #f39c12;   /* suspendido = naranja */
            border-radius: 24px;
            transition: background-color .3s;
        }
        .slider::before {
            content: "";
            position: absolute;
            width: 18px;
            height: 18px;
            left: 3px;
            bottom: 3px;
            background: #fff;
            border-radius: 50%;
            transition: transform .3s;
        }
        input:checked + .slider { background-color: #27ae60; /* activo = verde */ }
        input:checked + .slider::before { transform: translateX(22px); }
        .switch-label {
            font-size: .78rem;
            font-weight: 600;
            min-width: 68px;
        }
    </style>
    

    <script src="../assets/js/sidebar.js"></script>
    <script src="../assets/js/datatables-init.js"></script>