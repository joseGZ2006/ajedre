<?php
session_start();
include("../../modelo/conexion.php");
include("../../modelo/clase_clase.php");
include_once("../../controlador/verificar_sesion.php");

$claseObj = new Clase();
$clases   = $claseObj->ListarClases();
?>
<!DOCTYPE html>
<html lang="es">
<head><?php include '../assets/inc/head.php'; ?></head>
<body>
<div class="page-container">
    <?php include '../assets/inc/sidebar.php'; ?>
    <?php include '../assets/inc/header.php'; ?>

    <div class="main-content">
        <div class="catalog-header">
            <h1 class="page-title"><i class="fas fa-chalkboard-teacher me-2"></i> ASIGNACIONES DE CLASE</h1>
            <a href="./insert_asignacion_clase.php" class="btn btn-custom"><i class="fas fa-plus-circle me-2"></i>Nueva Asignación</a>
        </div>

        <div class="table-responsive">
            <table class="table alumno-table" id="asignacionClaseTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Alumno</th>
                        <th>Entrenador</th>
                        <th>Horario</th>
                        <th>Fecha Inicio</th>
                        <th>Fecha Fin</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($clases && count($clases) > 0): ?>
                        <?php foreach($clases as $row): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['idClase']); ?></td>
                            <td><?php echo htmlspecialchars($row['nombre_alumno'].' '.$row['apellido_alumno']); ?></td>
                            <td><?php echo htmlspecialchars($row['nombre_entrenador'].' '.$row['apellido_entrenador']); ?></td>
                            <td><?php echo htmlspecialchars($row['diaSemana'] ?? 'N/A') . ' ' . ($row['horaInicio'] ? date('h:i A', strtotime($row['horaInicio'])) : '') . ' - ' . ($row['horaFin'] ? date('h:i A', strtotime($row['horaFin'])) : ''); ?></td>
                            <td><?php echo date('d/m/Y', strtotime($row['fechaInicio'])); ?></td>
                            <td><?php echo $row['fechaFin'] ? date('d/m/Y', strtotime($row['fechaFin'])) : '<span class="badge bg-success">Activo</span>'; ?></td>
                            <td>
                                <a class="btn btn-sm btn-secondary"
                                   href="../../controlador/ctl_clase.php?C=con&I=<?php echo $row['idClase']; ?>">
                                   <i class="fas fa-eye"></i>
                                </a>
                                <?php if($_SESSION['rol_ses'] == 'admin'){  ?>
                                <a class="btn btn-sm btn-primary"
                                   href="../../controlador/ctl_clase.php?M=mos&I=<?php echo $row['idClase']; ?>">
                                   <i class="fas fa-edit"></i>
                                </a>
                                <button class="btn btn-sm btn-danger btn-delete"
                                        data-id="<?php echo base64_encode($row['idClase']); ?>"
                                        data-nombre="<?php echo htmlspecialchars($row['nombre_alumno'].' '.$row['apellido_alumno']); ?>">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                                <?php } ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center">No hay asignaciones de clase registradas</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../assets/inc/flash.php'; ?>
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sidebar.js"></script>
<script src="../assets/js/sweetalert2.all.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.btn-delete').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const idB64  = this.getAttribute('data-id');
            const nombre = this.getAttribute('data-nombre');
            Swal.fire({
                title: '¿Eliminar asignación?',
                text: `¿Eliminar la clase del alumno "${nombre}"?`,
                icon: 'warning', showCancelButton: true,
                confirmButtonColor: '#d33', cancelButtonColor: '#3085d6',
                confirmButtonText: 'Sí, eliminar', cancelButtonText: 'Cancelar', reverseButtons: true
            }).then(r => { if(r.isConfirmed) window.location.href = `../../controlador/ctl_clase.php?E=eli&I=${idB64}`; });
        });
    });
});
</script>
</body>
</html>