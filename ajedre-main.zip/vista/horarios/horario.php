<?php
session_start();
include("../../modelo/conexion.php");
include("../../modelo/clase_horario_clase.php");
include_once("../../controlador/verificar_sesion.php");

$horarioObj = new HorarioClase();
$horarios   = $horarioObj->ListarHorariosClase();
?>
<!DOCTYPE html>
<html lang="es">
<head><?php include '../assets/inc/head.php'; ?></head>
<body>
<div class="page-container">
    <?php include '../assets/inc/sidebar.php'; ?>
    <?php include '../assets/inc/header.php'; ?>

    <div class="main-content">
        <div class="catalog-header">
            <h1 class="page-title"><i class="fas fa-calendar-alt me-2"></i> HORARIOS DE CLASES</h1>
            <a href="./insert_horario.php" class="btn btn-custom"><i class="fas fa-plus-circle me-2"></i>Nuevo Horario</a>
        </div>

        <div class="table-responsive">
            <table class="table alumno-table" id="horarioTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Día</th>
                        <th>Hora Inicio</th>
                        <th>Hora Fin</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($horarios && count($horarios) > 0): ?>
                        <?php foreach($horarios as $row): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['idHorarioClase']); ?></td>
                            <td><?php echo htmlspecialchars($row['diaSemana']); ?></td>
                            <td><?php echo date('h:i A', strtotime($row['horaInicio'])); ?></td>
                            <td><?php echo date('h:i A', strtotime($row['horaFin'])); ?></td>
                            <td>
                                <a class="btn btn-sm btn-secondary"
                                   href="../../controlador/ctl_horario_clase.php?C=con&I=<?php echo $row['idHorarioClase']; ?>">
                                   <i class="fas fa-eye"></i>
                                </a>
                                <a class="btn btn-sm btn-primary"
                                   href="../../controlador/ctl_horario_clase.php?M=mos&I=<?php echo $row['idHorarioClase']; ?>">
                                   <i class="fas fa-edit"></i>
                                </a>
                                <button class="btn btn-sm btn-danger btn-delete"
                                        data-id="<?php echo base64_encode($row['idHorarioClase']); ?>"
                                        data-dia="<?php echo htmlspecialchars($row['diaSemana']); ?>"
                                        data-horario="<?php echo date('h:i A', strtotime($row['horaInicio'])) . ' - ' . date('h:i A', strtotime($row['horaFin'])); ?>">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center">No hay horarios registrados</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../assets/inc/flash.php'; ?>
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sidebar.js"></script>
<script src="../assets/js/sweetalert2.all.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.btn-delete').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const idB64  = this.getAttribute('data-id');
            const dia    = this.getAttribute('data-dia');
            const horario= this.getAttribute('data-horario');
            Swal.fire({
                title: '¿Eliminar horario?',
                text: `¿Eliminar ${dia} (${horario})?`,
                icon: 'warning', showCancelButton: true,
                confirmButtonColor: '#d33', cancelButtonColor: '#3085d6',
                confirmButtonText: 'Sí, eliminar', cancelButtonText: 'Cancelar', reverseButtons: true
            }).then(r => { if(r.isConfirmed) window.location.href = `../../controlador/ctl_horario_clase.php?E=eli&I=${idB64}`; });
        });
    });
});
</script>
</body>
</html>