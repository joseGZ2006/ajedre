<?php
session_start();
include_once("../../controlador/verificar_sesion.php");
include("../../modelo/conexion.php");
include("../../modelo/clase_alumno.php");
include("../../modelo/clase_entrenador.php");
include("../../modelo/clase_horario_clase.php");

$id          = isset($_GET['id'])          ? base64_decode($_GET['id'])          : '';
$idAlumno    = isset($_GET['idAlumno'])    ? base64_decode($_GET['idAlumno'])    : '';
$idEntrenador= isset($_GET['idEntrenador'])? base64_decode($_GET['idEntrenador']): '';
$idHorario   = isset($_GET['idHorario'])   ? base64_decode($_GET['idHorario'])   : '';
$fechaInicio = isset($_GET['fechaInicio']) ? base64_decode($_GET['fechaInicio']) : '';
$fechaFin    = isset($_GET['fechaFin'])    ? base64_decode($_GET['fechaFin'])    : '';

if(empty($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'Clase no encontrada.']; header("Location: ./asignacion_clase.php"); exit; }

$alumniObj  = new Alumno();    $alumnos    = $alumniObj->ListarAlumnos();
$entrenObj  = new Entrenador(); $entrenadores= $entrenObj->ListarEntrenadores();
$horarioObj = new HorarioClase(); $horarios = $horarioObj->ListarHorariosClase();
?>
<!DOCTYPE html>
<html lang="es">
<head><?php include '../assets/inc/head.php'; ?></head>
<body>
<div class="page-container">
    <?php include '../assets/inc/sidebar.php'; ?>
    <?php include '../assets/inc/header.php'; ?>

    <div class="main-content">
        <div class="catalog-header">
            <h1 class="page-title"><i class="fas fa-edit me-2"></i> Editar Asignación de Clase</h1>
            <a href="./asignacion_clase.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-2"></i>Volver</a>
        </div>

        <div class="form-card">
            <form method="POST" action="../../controlador/ctl_clase.php">
                <h3 class="section-title">Actualizar Clase</h3>
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($_GET['id']); ?>">

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label required-star">Alumno</label>
                        <select class="form-select" name="idAlumno" required>
                            <option value="">Seleccione un alumno</option>
                            <?php if($alumnos): foreach($alumnos as $a): ?>
                                <option value="<?php echo $a['idAlumno']; ?>" <?php echo ($a['idAlumno'] == $idAlumno) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($a['cedula'].' - '.$a['nombre'].' '.$a['apellido']); ?>
                                </option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label required-star">Entrenador</label>
                        <select class="form-select" name="idEntrenador" required>
                            <option value="">Seleccione un entrenador</option>
                            <?php if($entrenadores): foreach($entrenadores as $e): ?>
                                <option value="<?php echo $e['idEntrenador']; ?>" <?php echo ($e['idEntrenador'] == $idEntrenador) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($e['cedula'].' - '.$e['nombre'].' '.$e['apellido']); ?>
                                </option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label required-star">Horario</label>
                        <select class="form-select" name="idHorarioClase" required>
                            <option value="">Seleccione un horario</option>
                            <?php if($horarios): foreach($horarios as $h): ?>
                                <option value="<?php echo $h['idHorarioClase']; ?>" <?php echo ($h['idHorarioClase'] == $idHorario) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($h['diaSemana'].' '.date('h:i A',strtotime($h['horaInicio'])).' - '.date('h:i A',strtotime($h['horaFin']))); ?>
                                </option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label required-star">Fecha Inicio</label>
                        <input type="date" class="form-control" name="fechaInicio" value="<?php echo htmlspecialchars($fechaInicio); ?>" required>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Fecha Fin <small class="text-muted">(opcional)</small></label>
                        <input type="date" class="form-control" name="fechaFin" value="<?php echo htmlspecialchars($fechaFin); ?>">
                    </div>
                </div>
                <div class="form-actions">
                    <button type="reset" class="btn btn-danger"><i class="fas fa-eraser me-2"></i>Limpiar</button>
                    <button type="submit" class="btn btn-primary" name="actualizar" value="actualizar"><i class="fas fa-save me-2"></i>Actualizar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../assets/inc/flash.php'; ?>
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sweetalert2.all.min.js"></script>
<script src="../assets/js/sidebar.js"></script>
</body>
</html>