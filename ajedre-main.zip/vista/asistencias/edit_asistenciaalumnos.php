<?php
session_start();
// Verificar sesión antes de mostrar el dashboard
include_once("../../controlador/verificar_sesion.php");
include("../../modelo/conexion.php");

$id      = isset($_GET['id']) ? base64_decode($_GET['id']) : '';
$clase   = isset($_GET['clase']) ? base64_decode($_GET['clase']) : '';
$fecha   = isset($_GET['fecha']) ? base64_decode($_GET['fecha']) : '';
$entrada = isset($_GET['entrada']) ? base64_decode($_GET['entrada']) : '';
$salida  = isset($_GET['salida']) ? base64_decode($_GET['salida']) : '';
$estatus = isset($_GET['estatus']) ? base64_decode($_GET['estatus']) : '';
$obs     = isset($_GET['obs']) ? base64_decode($_GET['obs']) : '';

try {
    $stmt = $conex->prepare("
        SELECT c.idClase, a.nombre, a.apellido, a.cedula, h.diaSemana, h.horaInicio, h.horaFin
        FROM CLASE c
        JOIN ALUMNO a ON c.idAlumno = a.idAlumno
        LEFT JOIN HORARIO_CLASE h ON c.idHorarioClase = h.idHorarioClase
        ORDER BY a.apellido ASC, a.nombre ASC
    ");
    $stmt->execute();
    $clases = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $clases = [];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include '../assets/inc/head.php'; ?>
</head>

<body>
<div class="page-container">

    <!-- SIDEBAR -->
    <?php include '../assets/inc/sidebar.php'; ?>

    <!-- HEADER -->
    <?php include '../assets/inc/header.php'; ?>
        
     

    <!-- MAIN -->
    <div class="main-content">

        <div class="catalog-header">
            <h1 class="page-title">
                <i class="fas fa-edit me-2"></i> Editar Asistencia Alumnos
            </h1>

            <a href="./asistencia.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-2"></i> Volver
            </a>
        </div>

        <!-- FORMULARIO -->
        <div class="form-card">

            <form method="POST" action="../../controlador/ctl_asistencia_alumno.php" onsubmit="return validarEditarAsistenciaAlumnos(event)">
                <input type="hidden" name="actualizar" value="actualizar">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars(base64_encode($id)); ?>">

                <h3 class="section-title">Datos de Asistencia</h3>

                <!-- ALUMNO / CLASE -->
                <div class="mb-3">
                    <label class="form-label required-star">Alumno / Asignación de Clase</label>
                    <select class="form-select" id="idAsignacionClase" name="idAsignacionClase" required>
                        <option value="">Seleccionar alumno y clase</option>
                        <?php foreach($clases as $c): ?>
                            <option value="<?php echo $c['idClase']; ?>" <?php echo $c['idClase'] == $clase ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($c['cedula'].' - '.$c['nombre'].' '.$c['apellido'] . ($c['diaSemana'] ? ' ('.$c['diaSemana'].' '.date('h:i A', strtotime($c['horaInicio'])).')' : '')); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback-real" id="idAsignacionClaseFeedback"></div>
                </div>

                <!-- FECHA -->
                <div class="mb-3">
                    <label class="form-label required-star">Fecha</label>
                    <input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo htmlspecialchars($fecha); ?>" required>
                    <div class="invalid-feedback-real" id="fechaFeedback"></div>
                </div>

                <!-- HORA -->
                <div class="mb-3">
                    <label class="form-label required-star">Hora</label>
                    <input type="text" class="form-control" id="hora" name="horaEntrada" value="<?php echo htmlspecialchars($entrada ? date("h:i A", strtotime($entrada)) : ''); ?>" placeholder="Ej: 09:00 AM" required>
                    <div class="invalid-feedback-real" id="horaFeedback"></div>
                </div>

                <!-- ESTATUS -->
                <div class="mb-3">
                    <label class="form-label required-star">Estatus</label>
                    <select class="form-select" id="estatus" name="estatus" required>
                        <option value="">Seleccionar estatus</option>
                        <option value="presente" <?php echo $estatus == 'presente' ? 'selected' : ''; ?>>Presente</option>
                        <option value="ausente" <?php echo $estatus == 'ausente' ? 'selected' : ''; ?>>Ausente</option>
                        <option value="tarde" <?php echo $estatus == 'tarde' ? 'selected' : ''; ?>>Tarde</option>
                        <option value="justificado" <?php echo $estatus == 'justificado' ? 'selected' : ''; ?>>Justificado</option>
                    </select>
                    <div class="invalid-feedback-real" id="estatusFeedback"></div>
                </div>

                <!-- OBSERVACIÓN -->
                <div class="mb-3">
                    <label class="form-label required-star">Observación</label>
                    <textarea class="form-control" id="observacion" name="observacion" required><?php echo htmlspecialchars($obs); ?></textarea>
                    <div class="invalid-feedback-real" id="observacionFeedback"></div>
                </div>

                <!-- BOTONES -->
                <div class="form-actions">

                    <button type="reset" class="btn btn-danger" id="resetBtn">
                        <i class="fas fa-eraser me-2"></i> Limpiar
                    </button>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i> Actualizar
                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sweetalert2.all.min.js"></script>
<script src="../assets/js/sidebar.js"></script>

<!-- VALIDACIÓN -->
<script src="../assets/js/validaciones_editasistenciaalumnos.js"></script>

</body>
</html>