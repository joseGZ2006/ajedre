<?php
class AsistenciaEntrenador {

    ## REGISTRAR
    public function RegistrarAsistenciaEntrenador($idEntrenador, $fecha, $horaEntrada, $horaSalida, $alumnosEntrenados, $observacion) {
        include("conexion.php");
        if (empty($idEntrenador) || !is_numeric($idEntrenador))
            return ['success' => false, 'error' => 'Entrenador no válido.'];
        if (empty($fecha))
            return ['success' => false, 'error' => 'La fecha es requerida.'];
        try {
            $sql = $conex->prepare("INSERT INTO ASISTENCIA_ENTRENADOR (idEntrenador, fecha, horaEntrada, horaSalida, alumnosEntrenados, observacion) VALUES (?, ?, ?, ?, ?, ?)");
            $ok  = $sql->execute([$idEntrenador, $fecha, $horaEntrada ?: null, $horaSalida ?: null, is_numeric($alumnosEntrenados) ? $alumnosEntrenados : null, $observacion ?: null]);
            return $ok ? ['success' => true] : ['success' => false, 'error' => 'Error al registrar.'];
        } catch (PDOException $e) {
            error_log("Error RegistrarAsistenciaEntrenador: " . $e->getMessage());
            return ['success' => false, 'error' => 'Error en la base de datos.'];
        }
    }

    ## LISTAR
    public function ListarAsistenciasEntrenador() {
        include("conexion.php");
        try {
            $sql = $conex->prepare("
                SELECT ae.*, e.nombre AS nombre_entrenador, e.apellido AS apellido_entrenador, e.cedula AS cedula_entrenador
                FROM ASISTENCIA_ENTRENADOR ae
                LEFT JOIN ENTRENADOR e ON ae.idEntrenador = e.idEntrenador
                ORDER BY ae.fecha DESC, ae.idAsistenciaEntrenador DESC
            ");
            $sql->execute();
            return $sql->rowCount() > 0 ? $sql->fetchAll(PDO::FETCH_ASSOC) : false;
        } catch (PDOException $e) {
            error_log("Error ListarAsistenciasEntrenador: " . $e->getMessage());
            return false;
        }
    }

    ## CONSULTAR
    public function ConsultarAsistenciaEntrenador($id) {
        include("conexion.php");
        try {
            $sql = $conex->prepare("
                SELECT ae.*, e.nombre AS nombre_entrenador, e.apellido AS apellido_entrenador, e.cedula AS cedula_entrenador, e.telefono AS telefono_entrenador
                FROM ASISTENCIA_ENTRENADOR ae
                LEFT JOIN ENTRENADOR e ON ae.idEntrenador = e.idEntrenador
                WHERE ae.idAsistenciaEntrenador = ?
            ");
            $sql->execute([$id]);
            return $sql->rowCount() > 0 ? $sql->fetch(PDO::FETCH_ASSOC) : false;
        } catch (PDOException $e) {
            error_log("Error ConsultarAsistenciaEntrenador: " . $e->getMessage());
            return false;
        }
    }

    ## ACTUALIZAR
    public function ActualizarAsistenciaEntrenador($id, $idEntrenador, $fecha, $horaEntrada, $horaSalida, $alumnosEntrenados, $observacion) {
        include("conexion.php");
        if (empty($idEntrenador) || !is_numeric($idEntrenador))
            return ['success' => false, 'error' => 'Entrenador no válido.'];
        if (empty($fecha))
            return ['success' => false, 'error' => 'La fecha es requerida.'];
        try {
            $sql = $conex->prepare("UPDATE ASISTENCIA_ENTRENADOR SET idEntrenador=?, fecha=?, horaEntrada=?, horaSalida=?, alumnosEntrenados=?, observacion=? WHERE idAsistenciaEntrenador=?");
            $ok  = $sql->execute([$idEntrenador, $fecha, $horaEntrada ?: null, $horaSalida ?: null, is_numeric($alumnosEntrenados) ? $alumnosEntrenados : null, $observacion ?: null, $id]);
            return $ok ? ['success' => true] : ['success' => false, 'error' => 'Error al actualizar.'];
        } catch (PDOException $e) {
            error_log("Error ActualizarAsistenciaEntrenador: " . $e->getMessage());
            return ['success' => false, 'error' => 'Error en la base de datos.'];
        }
    }

    ## ELIMINAR
    public function EliminarAsistenciaEntrenador($id) {
        include("conexion.php");
        try {
            $sql = $conex->prepare("DELETE FROM ASISTENCIA_ENTRENADOR WHERE idAsistenciaEntrenador = ?");
            $ok  = $sql->execute([$id]);
            return $ok ? ['success' => true] : ['success' => false, 'error' => 'Error al eliminar.'];
        } catch (PDOException $e) {
            error_log("Error EliminarAsistenciaEntrenador: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}
?>
