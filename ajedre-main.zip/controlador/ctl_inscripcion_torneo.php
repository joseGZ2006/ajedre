<?php
session_start();
include("../modelo/conexion.php");
include("../modelo/clase_inscripcion_torneo.php");
$inscripcion = new InscripcionTorneo();
// Función para validar fecha
function validarFechaInscripcion($fecha) {
    if(empty($fecha)) {
        return false;
    }
    $fechaObj = DateTime::createFromFormat('Y-m-d', $fecha);
    return $fechaObj && $fechaObj->format('Y-m-d') === $fecha;
}
// Función para validar estatus
function validarEstatusInscripcion($estatus) {
    $estatusPermitidos = ['pendiente', 'confirmado', 'rechazado', 'cancelado'];
    return in_array($estatus, $estatusPermitidos);
}
// Función para validar pago
function validarPagoInscripcion($pago) {
    return $pago === '0' || $pago === '1' || $pago === 0 || $pago === 1;
}
############################################################################
### REGISTRAR ##############################################################
############################################################################
if(isset($_POST['registrar']) && $_POST['registrar'] == "registrar"){
    $errores = [];
    $idAlumno = isset($_POST['idAlumno']) ? $_POST['idAlumno'] : '';
    $idTorneo = isset($_POST['idTorneo']) ? $_POST['idTorneo'] : '';
    $fecha = isset($_POST['fecha']) ? trim($_POST['fecha']) : '';
    $estatus = isset($_POST['estatus']) ? $_POST['estatus'] : '';
    $pago = isset($_POST['pago']) ? $_POST['pago'] : '';
    
    if(empty($idAlumno) || !is_numeric($idAlumno)) {
        $errores[] = "Debe seleccionar un alumno válido";
    }
    
    if(empty($idTorneo) || !is_numeric($idTorneo)) {
        $errores[] = "Debe seleccionar un torneo válido";
    }
    
    if(empty($fecha)) {
        $errores[] = "La fecha de inscripción es requerida";
    } elseif(!validarFechaInscripcion($fecha)) {
        $errores[] = "La fecha de inscripción no es válida (formato YYYY-MM-DD)";
    }
    
    if(empty($estatus)) {
        $errores[] = "El estatus es requerido";
    } elseif(!validarEstatusInscripcion($estatus)) {
        $errores[] = "El estatus seleccionado no es válido";
    }
    
    if($pago === '') {
        $errores[] = "El estado de pago es requerido";
    } elseif(!validarPagoInscripcion($pago)) {
        $errores[] = "El estado de pago no es válido";
    }
    
    if(!empty($errores)) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error de Validación', 'text' => implode('<br>', $errores)];
        header("Location: ../vista/inscripcion_torneo/insert_inscripcion_torneo.php");
        exit;
    }
    $resultado = $inscripcion->RegistrarInscripcionTorneo($idAlumno, $idTorneo, $fecha, $estatus, $pago);
    
    if($resultado['success']){ 
        $_SESSION['flash'] = ['icon' => 'success', 'title' => 'Éxito', 'text' => 'Inscripción a Torneo registrada con éxito.'];
        header("Location: ../vista/inscripcion_torneo/inscripcion_torneo.php");
        exit;
    } else {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => $resultado['error']];
        header("Location: ../vista/inscripcion_torneo/insert_inscripcion_torneo.php");
        exit;
    }
}
############################################################################
### LISTAR #################################################################
############################################################################
if(isset($_GET['L']) && $_GET['L'] == "lis"){
    $datos = $inscripcion->ListarInscripcionesTorneo();
    if($datos === false || empty($datos)){
        $_SESSION['flash'] = ['icon' => 'info', 'title' => 'Información', 'text' => 'No hay inscripciones registradas.'];
    }
    
    header("Location: ../vista/inscripcion_torneo/inscripcion_torneo.php");
    exit;
}
#############################################################################
### CONSULTAR (VER DETALLE) #################################################
#############################################################################
if(isset($_GET['C']) && $_GET['C'] == "con"){
    if(!isset($_GET['I'])) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'ID de inscripción no proporcionado.'];
        header("Location: ../vista/inscripcion_torneo/inscripcion_torneo.php");
        exit;
    }
    
    $id = $_GET['I'];
    
    if(!is_numeric($id)) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'ID de inscripción inválido.'];
        header("Location: ../vista/inscripcion_torneo/inscripcion_torneo.php");
        exit;
    }
    
    $datos = $inscripcion->ConsultarInscripcionTorneo($id);
    
    if($datos === false){
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'No se encontró la inscripción solicitada.'];
        header("Location: ../vista/inscripcion_torneo/inscripcion_torneo.php");
        exit;
    } else {
        $idEncoded = base64_encode($datos['idInscripcionTorneo']);
        $nombreAlumnoEncoded = base64_encode($datos['nombre_alumno'] . ' ' . $datos['apellido_alumno']);
        $cedulaAlumnoEncoded = base64_encode($datos['cedula_alumno']);
        $categoriaAlumnoEncoded = base64_encode($datos['categoria_alumno'] ?? 'N/A');
        $nombreTorneoEncoded = base64_encode($datos['nombre_torneo']);
        $fechaTorneoEncoded = base64_encode($datos['fecha_torneo']);
        $lugarTorneoEncoded = base64_encode($datos['lugar_torneo'] ?? 'N/A');
        $fechaInscripcionEncoded = base64_encode($datos['fecha']);
        $estatusEncoded = base64_encode($datos['estatus']);
        $pagoEncoded = base64_encode($datos['pago']);
        
        header("Location: ../vista/inscripcion_torneo/detalle_inscripcion_torneo.php?id=$idEncoded&alumno=$nombreAlumnoEncoded&cedula=$cedulaAlumnoEncoded&categoria=$categoriaAlumnoEncoded&torneo=$nombreTorneoEncoded&fecha_torneo=$fechaTorneoEncoded&lugar_torneo=$lugarTorneoEncoded&fecha=$fechaInscripcionEncoded&estatus=$estatusEncoded&pago=$pagoEncoded");
        exit;
    }
}
############################################################################
### MOSTRAR PARA EDITAR ####################################################
############################################################################
if(isset($_GET['M']) && $_GET['M'] == "mos"){
    if(!isset($_GET['I'])) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'ID de inscripción no proporcionado.'];
        header("Location: ../vista/inscripcion_torneo/inscripcion_torneo.php");
        exit;
    }
    
    $id = $_GET['I'];
    
    if(!is_numeric($id)) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'ID de inscripción inválido.'];
        header("Location: ../vista/inscripcion_torneo/inscripcion_torneo.php");
        exit;
    }
    
    $datos = $inscripcion->MostrarInscripcionTorneo($id);
    
    if($datos === false){
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'No se encontró la inscripción solicitada.'];
        header("Location: ../vista/inscripcion_torneo/inscripcion_torneo.php");
        exit;
    } else {
        $idEncoded = base64_encode($datos['idInscripcionTorneo']);
        $idAlumnoEncoded = base64_encode($datos['idAlumno']);
        $idTorneoEncoded = base64_encode($datos['idTorneo']);
        $fechaEncoded = base64_encode($datos['fecha']);
        $estatusEncoded = base64_encode($datos['estatus']);
        $pagoEncoded = base64_encode($datos['pago']);
        
        header("Location: ../vista/inscripcion_torneo/edit_inscripcion_torneo.php?id=$idEncoded&alumno=$idAlumnoEncoded&torneo=$idTorneoEncoded&fecha=$fechaEncoded&estatus=$estatusEncoded&pago=$pagoEncoded");
        exit;
    }
}
############################################################################
### ACTUALIZAR #############################################################
############################################################################
if(isset($_POST['actualizar']) && $_POST['actualizar'] == "actualizar"){
    $errores = [];
    $idAlumno = isset($_POST['idAlumno']) ? $_POST['idAlumno'] : '';
    $idTorneo = isset($_POST['idTorneo']) ? $_POST['idTorneo'] : '';
    $fecha = isset($_POST['fecha']) ? trim($_POST['fecha']) : '';
    $estatus = isset($_POST['estatus']) ? $_POST['estatus'] : '';
    $pago = isset($_POST['pago']) ? $_POST['pago'] : '';
    
    if(empty($idAlumno) || !is_numeric($idAlumno)) {
        $errores[] = "Debe seleccionar un alumno válido";
    }
    
    if(empty($idTorneo) || !is_numeric($idTorneo)) {
        $errores[] = "Debe seleccionar un torneo válido";
    }
    
    if(empty($fecha)) {
        $errores[] = "La fecha de inscripción es requerida";
    } elseif(!validarFechaInscripcion($fecha)) {
        $errores[] = "La fecha de inscripción no es válida (formato YYYY-MM-DD)";
    }
    
    if(empty($estatus)) {
        $errores[] = "El estatus es requerido";
    } elseif(!validarEstatusInscripcion($estatus)) {
        $errores[] = "El estatus seleccionado no es válido";
    }
    
    if($pago === '') {
        $errores[] = "El estado de pago es requerido";
    } elseif(!validarPagoInscripcion($pago)) {
        $errores[] = "El estado de pago no es válido";
    }
    
    if(!empty($errores)) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error de Validación', 'text' => implode('<br>', $errores)];
        $idParam = isset($_POST['id']) ? $_POST['id'] : '';
        $alumnoParam = isset($_POST['alumno_original']) ? $_POST['alumno_original'] : '';
        $torneoParam = isset($_POST['torneo_original']) ? $_POST['torneo_original'] : '';
        $fechaParam = isset($_POST['fecha_original']) ? $_POST['fecha_original'] : '';
        $estatusParam = isset($_POST['estatus_original']) ? $_POST['estatus_original'] : '';
        $pagoParam = isset($_POST['pago_original']) ? $_POST['pago_original'] : '';
        header("Location: ../vista/inscripcion_torneo/edit_inscripcion_torneo.php?id=$idParam&alumno=$alumnoParam&torneo=$torneoParam&fecha=$fechaParam&estatus=$estatusParam&pago=$pagoParam");
        exit;
    }
    $id = base64_decode($_POST['id']);
    
    $resultado = $inscripcion->ActualizarInscripcionTorneo($id, $idAlumno, $idTorneo, $fecha, $estatus, $pago);
    
    if($resultado['success']){ 
        $_SESSION['flash'] = ['icon' => 'success', 'title' => 'Éxito', 'text' => 'Inscripción a Torneo actualizada con éxito.'];
        header("Location: ../vista/inscripcion_torneo/inscripcion_torneo.php");
        exit;
    } else {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => $resultado['error']];
        $idParam = isset($_POST['id']) ? $_POST['id'] : '';
        $alumnoParam = isset($_POST['alumno_original']) ? $_POST['alumno_original'] : '';
        $torneoParam = isset($_POST['torneo_original']) ? $_POST['torneo_original'] : '';
        $fechaParam = isset($_POST['fecha_original']) ? $_POST['fecha_original'] : '';
        $estatusParam = isset($_POST['estatus_original']) ? $_POST['estatus_original'] : '';
        $pagoParam = isset($_POST['pago_original']) ? $_POST['pago_original'] : '';
        header("Location: ../vista/inscripcion_torneo/edit_inscripcion_torneo.php?id=$idParam&alumno=$alumnoParam&torneo=$torneoParam&fecha=$fechaParam&estatus=$estatusParam&pago=$pagoParam");
        exit;
    }
}
############################################################################
### ELIMINAR ###############################################################
############################################################################
if(isset($_GET['E']) && $_GET['E'] == "eli"){
    if(!isset($_GET['I'])) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'ID de inscripción no proporcionado.'];
        header("Location: ../vista/inscripcion_torneo/inscripcion_torneo.php");
        exit;
    }
    
    $id = base64_decode($_GET['I']);
    
    if(!is_numeric($id)) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'ID de inscripción inválido.'];
        header("Location: ../vista/inscripcion_torneo/inscripcion_torneo.php");
        exit;
    }
    
    $resultado = $inscripcion->EliminarInscripcionTorneo($id);
    
    if($resultado['success']){
        $_SESSION['flash'] = ['icon' => 'success', 'title' => 'Éxito', 'text' => 'Inscripción a Torneo eliminada con éxito.'];
    } else {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => $resultado['error']];
    }
    
    header("Location: ../vista/inscripcion_torneo/inscripcion_torneo.php");
    exit;
}
?>
