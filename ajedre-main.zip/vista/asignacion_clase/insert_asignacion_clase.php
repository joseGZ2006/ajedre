<?php
session_start();
include_once("../../controlador/verificar_sesion.php");
include("../../modelo/conexion.php");
include("../../modelo/clase_alumno.php");
include("../../modelo/clase_entrenador.php");
include("../../modelo/clase_horario_clase.php");

$alumniObj  = new Alumno();
$alumnos    = $alumniObj->ListarAlumnos();

$entrenObj  = new Entrenador();
$entrenadores = $entrenObj->ListarEntrenadores();

$horarioObj = new HorarioClase();
$horarios   = $horarioObj->ListarHorariosClase();
?>
<!DOCTYPE html>
<html lang="es">
<head><?php include '../assets/inc/head.php'; ?></head>
<body>
<div class="page-container">
    <?php include '../assets/inc/sidebar.php'; ?>
    <?php include '../assets/inc/header.php'; ?>

    <div class="main-content">
        <div class="catalog-header">
            
            <a href="./asignacion_clase.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-2"></i>Volver</a>
        </div>

        <div class="form-card">
            <form method="POST" action="../../controlador/ctl_clase.php">
                <h3 class="section-title">Datos de la Clase</h3>
                <div class="row">
                    <!-- ALUMNO -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label required-star">Alumno</label>
                        <select class="form-select" name="idAlumno" id="idAlumno" required>
                            <option value="">Seleccione un alumno</option>
                            <?php if($alumnos): foreach($alumnos as $a): ?>
                                <option value="<?php echo $a['idAlumno']; ?>">
                                    <?php echo htmlspecialchars($a['cedula'].' - '.$a['nombre'].' '.$a['apellido']); ?>
                                </option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                    <!-- ENTRENADOR -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label required-star">Entrenador</label>
                        <select class="form-select" name="idEntrenador" id="idEntrenador" required>
                            <option value="">Seleccione un entrenador</option>
                            <?php if($entrenadores): foreach($entrenadores as $e): ?>
                                <option value="<?php echo $e['idEntrenador']; ?>">
                                    <?php echo htmlspecialchars($e['cedula'].' - '.$e['nombre'].' '.$e['apellido']); ?>
                                </option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                    <!-- HORARIO -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label required-star">Horario</label>
                        <select class="form-select" name="idHorarioClase" id="idHorarioClase" required>
                            <option value="">Seleccione un horario</option>
                            <?php if($horarios): foreach($horarios as $h): ?>
                                <option value="<?php echo $h['idHorarioClase']; ?>">
                                    <?php echo htmlspecialchars($h['diaSemana'].' '.date('h:i A',strtotime($h['horaInicio'])).' - '.date('h:i A',strtotime($h['horaFin']))); ?>
                                </option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>
                    <!-- FECHA INICIO -->
                    <div class="col-md-3 mb-3">
                        <label class="form-label required-star">Fecha Inicio</label>
                        <input type="date" class="form-control" name="fechaInicio" id="fechaInicio" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <!-- FECHA FIN -->
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Fecha Fin <small class="text-muted">(opcional)</small></label>
                        <input type="date" class="form-control" name="fechaFin" id="fechaFin">
                    </div>
                </div>
                <div class="form-actions">
                    <button type="reset" class="btn btn-danger"><i class="fas fa-eraser me-2"></i>Limpiar</button>
                    <button type="submit" class="btn btn-primary" name="registrar" value="registrar"><i class="fas fa-save me-2"></i>Registrar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../assets/inc/flash.php'; ?>
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sweetalert2.all.min.js"></script>
<script src="../assets/js/sidebar.js"></script>
</body>
</html>