<?php
session_start();
include("../modelo/conexion.php");
include("../modelo/clase_asistencia_alumno.php");

$asistObj = new AsistenciaAlumno();

### REGISTRAR
if(isset($_POST['registrar']) && $_POST['registrar']=="registrar"){
    $idAsignacionClase = $_POST['idAsignacionClase'] ?? '';
    $fecha             = $_POST['fecha']             ?? '';
    $horaEntrada       = $_POST['horaEntrada']       ?? '';
    $horaSalida        = $_POST['horaSalida']        ?? '';
    $estatus           = $_POST['estatus']           ?? '';
    $observacion       = $_POST['observacion']       ?? '';

    if (!empty($horaEntrada)) {
        $horaEntrada = date("H:i:s", strtotime($horaEntrada));
    }
    if (!empty($horaSalida)) {
        $horaSalida = date("H:i:s", strtotime($horaSalida));
    }

    $resultado = $asistObj->RegistrarAsistenciaAlumno($idAsignacionClase, $fecha, $horaEntrada, $horaSalida, $estatus, $observacion);
    if($resultado['success']){
        $_SESSION['flash'] = ['icon'=>'success','title'=>'Éxito','text'=>'Asistencia de alumno registrada.'];
        header("Location: ../vista/asistencias/asistencia.php"); exit;
    } else {
        $_SESSION['flash'] = ['icon'=>'error','title'=>'Error','text'=>$resultado['error']];
        header("Location: ../vista/asistencias/insert_asistenciaalumnos.php"); exit;
    }
}

### CONSULTAR
if(isset($_GET['C']) && $_GET['C']=="con"){
    $id = $_GET['I'] ?? '';
    if(!is_numeric($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'ID inválido.']; header("Location: ../vista/asistencias/asistencia.php"); exit; }
    $datos = $asistObj->ConsultarAsistenciaAlumno($id);
    if(!$datos){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'Registro no encontrado.']; header("Location: ../vista/asistencias/asistencia.php"); exit; }
    $p = [
        'id'       => base64_encode($datos['idAsistenciaAlumno']),
        'alumno'   => base64_encode($datos['nombre_alumno'].' '.$datos['apellido_alumno']),
        'cedula'   => base64_encode($datos['cedula_alumno'] ?? ''),
        'clase'    => base64_encode($datos['idAsignacionClase']),
        'dia'      => base64_encode($datos['diaSemana'] ?? ''),
        'fecha'    => base64_encode($datos['fecha']),
        'entrada'  => base64_encode($datos['horaEntrada'] ?? ''),
        'salida'   => base64_encode($datos['horaSalida'] ?? ''),
        'estatus'  => base64_encode($datos['estatus']),
        'obs'      => base64_encode($datos['observacion'] ?? ''),
    ];
    header("Location: ../vista/asistencias/detalle_asistenciaalumnos.php?" . http_build_query($p)); exit;
}

### MOSTRAR (editar)
if(isset($_GET['M']) && $_GET['M']=="mos"){
    $id = $_GET['I'] ?? '';
    if(!is_numeric($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'ID inválido.']; header("Location: ../vista/asistencias/asistencia.php"); exit; }
    $datos = $asistObj->ConsultarAsistenciaAlumno($id);
    if(!$datos){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'Registro no encontrado.']; header("Location: ../vista/asistencias/asistencia.php"); exit; }
    $p = [
        'id'      => base64_encode($datos['idAsistenciaAlumno']),
        'clase'   => base64_encode($datos['idAsignacionClase']),
        'fecha'   => base64_encode($datos['fecha']),
        'entrada' => base64_encode($datos['horaEntrada'] ?? ''),
        'salida'  => base64_encode($datos['horaSalida'] ?? ''),
        'estatus' => base64_encode($datos['estatus']),
        'obs'     => base64_encode($datos['observacion'] ?? ''),
    ];
    header("Location: ../vista/asistencias/edit_asistenciaalumnos.php?" . http_build_query($p)); exit;
}

### ACTUALIZAR
if(isset($_POST['actualizar']) && $_POST['actualizar']=="actualizar"){
    $id                = base64_decode($_POST['id'] ?? '');
    $idAsignacionClase = $_POST['idAsignacionClase'] ?? '';
    $fecha             = $_POST['fecha']             ?? '';
    $horaEntrada       = $_POST['horaEntrada']       ?? '';
    $horaSalida        = $_POST['horaSalida']        ?? '';
    $estatus           = $_POST['estatus']           ?? '';
    $observacion       = $_POST['observacion']       ?? '';

    if (!empty($horaEntrada)) {
        $horaEntrada = date("H:i:s", strtotime($horaEntrada));
    }
    if (!empty($horaSalida)) {
        $horaSalida = date("H:i:s", strtotime($horaSalida));
    }

    $resultado = $asistObj->ActualizarAsistenciaAlumno($id, $idAsignacionClase, $fecha, $horaEntrada, $horaSalida, $estatus, $observacion);
    if($resultado['success']){
        $_SESSION['flash'] = ['icon'=>'success','title'=>'Éxito','text'=>'Asistencia actualizada.'];
        header("Location: ../vista/asistencias/asistencia.php"); exit;
    } else {
        $_SESSION['flash'] = ['icon'=>'error','title'=>'Error','text'=>$resultado['error']];
        header("Location: ../vista/asistencias/asistencia.php"); exit;
    }
}

### ELIMINAR
if(isset($_GET['E']) && $_GET['E']=="eli"){
    $id = base64_decode($_GET['I'] ?? '');
    if(!is_numeric($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'ID inválido.']; header("Location: ../vista/asistencias/asistencia.php"); exit; }
    $resultado = $asistObj->EliminarAsistenciaAlumno($id);
    $_SESSION['flash'] = $resultado['success']
        ? ['icon'=>'success','title'=>'Éxito','text'=>'Asistencia eliminada.']
        : ['icon'=>'error','title'=>'Error','text'=>$resultado['error']];
    header("Location: ../vista/asistencias/asistencia.php"); exit;
}
?>
