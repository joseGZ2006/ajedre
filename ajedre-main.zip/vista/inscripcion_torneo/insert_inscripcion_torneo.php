<?php
session_start();
// Verificar sesión antes de mostrar el dashboard
include_once("../../controlador/verificar_sesion.php");

include("../../modelo/conexion.php");
include("../../modelo/clase_alumno.php");
include("../../modelo/clase_torneo.php");

$alumniObj = new Alumno();
$alumnos = $alumniObj->ListarAlumnos();

$torneoObj = new Torneo();
$torneos = $torneoObj->ListarTorneo();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include '../assets/inc/head.php'; ?>
</head>

<body>
<div class="page-container">

    <!-- SIDEBAR -->
    <?php include '../assets/inc/sidebar.php'; ?>

    <!-- HEADER -->
    <?php include '../assets/inc/header.php'; ?>

        <!-- CONTENIDO -->
        <div class="main-content">
            <div class="catalog-header">
                <h1 class="page-title">
                    <i class="fas fa-plus-circle me-2"></i> Registrar Inscripción de Torneo
                </h1>
                <a href="./inscripcion_torneo.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-2"></i> Volver
                </a>
            </div>

            <div class="form-card">
                <form method="POST" action="../../controlador/ctl_inscripcion_torneo.php" onsubmit="return validarInscripcionTorneo(event)">
                    <h3 class="section-title">Datos de Inscripción de Torneo</h3>

                    <!-- ALUMNO -->
                    <div class="mb-3">
                        <label class="form-label required-star">Alumno</label>
                        <select class="form-select" id="idAlumno" name="idAlumno">
                            <option value="">Seleccione un alumno</option>
                            <?php if ($alumnos && count($alumnos) > 0): ?>
                                <?php foreach ($alumnos as $alumno): ?>
                                    <option value="<?php echo $alumno['idAlumno']; ?>">
                                        <?php echo htmlspecialchars($alumno['cedula'] . ' - ' . $alumno['nombre'] . ' ' . $alumno['apellido']); ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                        <div class="invalid-feedback-real" id="idAlumnoFeedback"></div>
                    </div>

                    <!-- TORNEO -->
                    <div class="mb-3">
                        <label class="form-label required-star">Torneo</label>
                        <select class="form-select" id="idTorneo" name="idTorneo">
                            <option value="">Seleccione un torneo</option>
                            <?php if ($torneos && count($torneos) > 0): ?>
                                <?php foreach ($torneos as $torneo): ?>
                                    <option value="<?php echo $torneo['idTorneo']; ?>">
                                        <?php echo htmlspecialchars($torneo['nombre'] . ' (' . date('d/m/Y', strtotime($torneo['fecha'])) . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                        <div class="invalid-feedback-real" id="idTorneoFeedback"></div>
                    </div>

                    <!-- FECHA -->
                    <div class="mb-3">
                        <label class="form-label required-star">Fecha de Inscripción</label>
                        <input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo date('Y-m-d'); ?>">
                        <div class="invalid-feedback-real" id="fechaFeedback"></div>
                    </div>

                    <!-- ESTATUS -->
                    <div class="mb-3">
                        <label class="form-label required-star">Estatus</label>
                        <select class="form-select" id="estatus" name="estatus">
                            <option value="">Seleccione un estatus</option>
                            <option value="pendiente" selected>Pendiente</option>
                            <option value="confirmado">Confirmado</option>
                            <option value="rechazado">Rechazado</option>
                            <option value="cancelado">Cancelado</option>
                        </select>
                        <div class="invalid-feedback-real" id="estatusFeedback"></div>
                    </div>

                    <!-- PAGO -->
                    <div class="mb-3">
                        <label class="form-label required-star">Estado de Pago</label>
                        <select class="form-select" id="pago" name="pago">
                            <option value="">Seleccione estado de pago</option>
                            <option value="0" selected>No Pagado</option>
                            <option value="1">Pagado</option>
                        </select>
                        <div class="invalid-feedback-real" id="pagoFeedback"></div>
                    </div>

                    <!-- BOTONES -->
                    <div class="form-actions">
                        <button type="reset" class="btn btn-danger" id="resetBtn">
                            <i class="fas fa-eraser me-2"></i> Limpiar
                        </button>
                        <button type="submit" class="btn btn-primary" name="registrar" value="registrar">
                            <i class="fas fa-save me-2"></i> Registrar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include '../assets/inc/flash.php'; ?>

    <script src="../assets/js/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/sweetalert2.all.min.js"></script>
    <script src="../assets/js/validaciones_inscripcion_torneo.js"></script>
    <script src="../assets/js/sidebar.js"></script>
</body>
</html>