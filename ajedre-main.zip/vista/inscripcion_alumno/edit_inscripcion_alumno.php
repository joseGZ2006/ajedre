<?php
session_start();
// Verificar sesión antes de mostrar el dashboard
include_once("../../controlador/verificar_sesion.php");

include("../../modelo/conexion.php");
include("../../modelo/clase_alumno.php");

// Recuperar y decodificar parámetros
$id      = isset($_GET['id'])      ? base64_decode($_GET['id'])      : '';
$idAlumno = isset($_GET['alumno']) ? base64_decode($_GET['alumno'])  : '';
$fecha   = isset($_GET['fecha'])   ? base64_decode($_GET['fecha'])   : '';
$estatus = isset($_GET['estatus']) ? base64_decode($_GET['estatus']) : '';

if (empty($id)) {
    $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'Inscripción no encontrada.'];
    header("Location: ./inscripcion_alumno.php");
    exit;
}

$alumniObj = new Alumno();
$alumnos = $alumniObj->ListarAlumnos();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include '../assets/inc/head.php'; ?>
</head>

<body>
<div class="page-container">

    <!-- SIDEBAR -->
    <?php include '../assets/inc/sidebar.php'; ?>

    <!-- HEADER -->
    <?php include '../assets/inc/header.php'; ?>

        <!-- CONTENIDO -->
        <div class="main-content">
            <div class="catalog-header">
                <h1 class="page-title">
                    <i class="fas fa-edit me-2"></i> Editar Inscripción de Alumno
                </h1>
                <a href="./inscripcion_alumno.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-2"></i> Volver
                </a>
            </div>

            <div class="form-card">
                <form method="POST" action="../../controlador/ctl_inscripcion_alumno.php" onsubmit="return validarInscripcionAlumno(event)">
                    <h3 class="section-title">Actualizar Inscripción</h3>

                    <!-- Campos ocultos para preservar parámetros en caso de error -->
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($_GET['id']); ?>">
                    <input type="hidden" name="alumno_original" value="<?php echo htmlspecialchars($_GET['alumno']); ?>">
                    <input type="hidden" name="fecha_original" value="<?php echo htmlspecialchars($_GET['fecha']); ?>">
                    <input type="hidden" name="estatus_original" value="<?php echo htmlspecialchars($_GET['estatus']); ?>">

                    <!-- ALUMNO -->
                    <div class="mb-3">
                        <label class="form-label required-star">Alumno</label>
                        <select class="form-select" id="idAlumno" name="idAlumno">
                            <option value="">Seleccione un alumno</option>
                            <?php if ($alumnos && count($alumnos) > 0): ?>
                                <?php foreach ($alumnos as $alumno): ?>
                                    <option value="<?php echo $alumno['idAlumno']; ?>" <?php echo ($alumno['idAlumno'] == $idAlumno) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($alumno['cedula'] . ' - ' . $alumno['nombre'] . ' ' . $alumno['apellido']); ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                        <div class="invalid-feedback-real" id="idAlumnoFeedback"></div>
                    </div>

                    <!-- FECHA -->
                    <div class="mb-3">
                        <label class="form-label required-star">Fecha de Inscripción</label>
                        <input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo htmlspecialchars($fecha); ?>">
                        <div class="invalid-feedback-real" id="fechaFeedback"></div>
                    </div>

                    <!-- ESTATUS -->
                    <div class="mb-3">
                        <label class="form-label required-star">Estatus</label>
                        <select class="form-select" id="estatus" name="estatus">
                            <option value="">Seleccione un estatus</option>
                            <option value="activo"     <?php echo ($estatus == 'activo')     ? 'selected' : ''; ?>>Activo</option>
                            <option value="inactivo"   <?php echo ($estatus == 'inactivo')   ? 'selected' : ''; ?>>Inactivo</option>
                            <option value="suspendido" <?php echo ($estatus == 'suspendido') ? 'selected' : ''; ?>>Suspendido</option>
                        </select>
                        <div class="invalid-feedback-real" id="estatusFeedback"></div>
                    </div>

                    <!-- BOTONES -->
                    <div class="form-actions">
                        <button type="reset" class="btn btn-danger" id="resetBtn">
                            <i class="fas fa-eraser me-2"></i> Limpiar
                        </button>
                        <button type="submit" class="btn btn-primary" name="actualizar" value="actualizar">
                            <i class="fas fa-save me-2"></i> Actualizar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include '../assets/inc/flash.php'; ?>

    <script src="../assets/js/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/sweetalert2.all.min.js"></script>
    <script src="../assets/js/validaciones_inscripcion_alumno.js"></script>
    <script src="../assets/js/sidebar.js"></script>
</body>
</html>
