<?php
session_start();
// Verificar sesión antes de mostrar el dashboard
include_once("../../controlador/verificar_sesion.php");

$alumno = isset($_GET['alumno']) ? base64_decode($_GET['alumno']) : '';
$cedula = isset($_GET['cedula']) ? base64_decode($_GET['cedula']) : '';
$fecha  = isset($_GET['fecha']) ? base64_decode($_GET['fecha']) : '';
$entrada = isset($_GET['entrada']) ? base64_decode($_GET['entrada']) : '';
$salida = isset($_GET['salida']) ? base64_decode($_GET['salida']) : '';
$estatus = isset($_GET['estatus']) ? base64_decode($_GET['estatus']) : '';
$obs     = isset($_GET['obs']) ? base64_decode($_GET['obs']) : '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include '../assets/inc/head.php'; ?>
</head>

<body>
<div class="page-container">

    <!-- SIDEBAR -->
    <?php include '../assets/inc/sidebar.php'; ?>

    <!-- HEADER -->
    <?php include '../assets/inc/header.php'; ?>

    <!-- MAIN -->
    <div class="main-content">

        <div class="detail-header">

            <div class="catalog-header">
                <h1 class="page-title">
                    <i class="fas fa-clipboard-list me-2"></i>
                    Detalle de Asistencia
                </h1>
            </div>

            <a href="./asistencia.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-2"></i> Volver
            </a>

        </div>

        <!-- AVATAR -->
        <div class="detail-avatar">

            <div class="avatar-large">
                <i class="fas fa-user-graduate"></i>
            </div>

            <h2 id="detalleAlumno"><?php echo htmlspecialchars($alumno); ?></h2>

        </div>

        <!-- INFO -->
        <div class="detail-info-grid">

            <div class="info-group">

                <label><i class="fas fa-info-circle me-2"></i>Datos de Asistencia</label>


                <div class="info-row">
                    <span class="info-label">Alumno:</span>
                    <span class="info-value" id="detalleAlumnoNombre"><?php echo htmlspecialchars($alumno); ?></span>
                </div>

                <div class="info-row">
                    <span class="info-label">Cédula:</span>
                    <span class="info-value" id="detalleCedula"><?php echo htmlspecialchars($cedula); ?></span>
                </div>

                <div class="info-row">
                    <span class="info-label">Fecha:</span>
                    <span class="info-value" id="detalleFecha"><?php echo htmlspecialchars($fecha); ?></span>
                </div>

                <div class="info-row">
                    <span class="info-label">Hora:</span>
                    <span class="info-value" id="detalleHora"><?php echo htmlspecialchars($entrada ? date("h:i A", strtotime($entrada)) : ''); ?></span>
                </div>

                <div class="info-row">
                    <span class="info-label">Estatus:</span>
                    <span class="info-value" id="detalleEstatus">
                        <?php 
                        $badgeClass = 'bg-secondary';
                        if ($estatus == 'presente') $badgeClass = 'bg-success';
                        elseif ($estatus == 'ausente') $badgeClass = 'bg-danger';
                        elseif ($estatus == 'tarde') $badgeClass = 'bg-warning text-dark';
                        elseif ($estatus == 'justificado') $badgeClass = 'bg-info text-dark';
                        ?>
                        <span class="badge <?php echo $badgeClass; ?>">
                            <?php echo ucfirst(htmlspecialchars($estatus)); ?>
                        </span>
                    </span>
                </div>

                <div class="info-row">
                    <span class="info-label">Observación:</span>
                    <span class="info-value" id="detalleObservacion"><?php echo htmlspecialchars($obs); ?></span>
                </div>

            </div>

        </div>

    </div>

</div>

<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sidebar.js"></script>

</body>
</html>