<?php
session_start();
// Verificar sesión antes de mostrar el dashboard
include_once("../../controlador/verificar_sesion.php");

// Decodificar los parámetros recibidos
$id = isset($_GET['id']) ? base64_decode($_GET['id']) : '';
$alumno = isset($_GET['alumno']) ? base64_decode($_GET['alumno']) : '';
$cedula = isset($_GET['cedula']) ? base64_decode($_GET['cedula']) : '';
$categoria = isset($_GET['categoria']) ? base64_decode($_GET['categoria']) : 'N/A';
$torneo = isset($_GET['torneo']) ? base64_decode($_GET['torneo']) : '';
$fecha_torneo = isset($_GET['fecha_torneo']) ? base64_decode($_GET['fecha_torneo']) : '';
$lugar_torneo = isset($_GET['lugar_torneo']) ? base64_decode($_GET['lugar_torneo']) : 'N/A';
$fecha = isset($_GET['fecha']) ? base64_decode($_GET['fecha']) : '';
$estatus = isset($_GET['estatus']) ? base64_decode($_GET['estatus']) : '';
$pago = isset($_GET['pago']) ? base64_decode($_GET['pago']) : '';

if (empty($id)) {
    $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'Inscripción no encontrada o ID inválido.'];
    header("Location: ./inscripcion_torneo.php");
    exit;
}

// Función para obtener badge de estatus
function getEstatusBadge($estatus) {
    $clases = [
        'pendiente' => 'bg-warning text-dark',
        'confirmado' => 'bg-success',
        'rechazado' => 'bg-danger',
        'cancelado' => 'bg-secondary'
    ];
    return isset($clases[$estatus]) ? $clases[$estatus] : 'bg-secondary';
}

// Función para obtener badge de pago
function getPagoBadge($pago) {
    return $pago == 1 ? 'bg-success' : 'bg-danger';
}

function getPagoTexto($pago) {
    return $pago == 1 ? 'Pagado' : 'No Pagado';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include '../assets/inc/head.php'; ?>
</head>

<body>
<div class="page-container">

    <!-- SIDEBAR -->
    <?php include '../assets/inc/sidebar.php'; ?>

    <!-- HEADER -->
    <?php include '../assets/inc/header.php'; ?>

    <!-- CONTENIDO -->
    <div class="main-content">
        <div class="detail-header">
            <div class="catalog-header">
                <h1 class="page-title">
                    <i class="fas fa-info-circle me-2"></i> Detalle de Inscripción a Torneo
                </h1>
            </div>
            <a href="./inscripcion_torneo.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-2"></i>Volver al catálogo
            </a>
        </div>

        <!-- AVATAR / ICONO -->
        <div class="detail-avatar">
            <div class="avatar-large">
                <i class="fas fa-trophy"></i>
            </div>
            <h2><?php echo htmlspecialchars($alumno); ?></h2>
            <p class="text-muted">Cédula: <?php echo htmlspecialchars($cedula); ?> | Categoría Alumno: <?php echo htmlspecialchars($categoria); ?></p>
            <p class="text-muted fw-bold">ID Inscripción: <?php echo htmlspecialchars($id); ?></p>
        </div>

        <!-- INFO -->
        <div class="detail-info-grid">
            <div class="info-group">
                <label>
                    <i class="fas fa-clipboard-list me-2"></i>
                    Información General de la Inscripción
                </label>
                <div class="info-row">
                    <span class="info-label">Alumno:</span>
                    <span class="info-value"><?php echo htmlspecialchars($alumno); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Cédula del Alumno:</span>
                    <span class="info-value"><?php echo htmlspecialchars($cedula); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Torneo:</span>
                    <span class="info-value"><?php echo htmlspecialchars($torneo); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Fecha del Torneo:</span>
                    <span class="info-value"><?php echo date('d/m/Y', strtotime($fecha_torneo)); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Lugar del Torneo:</span>
                    <span class="info-value"><?php echo htmlspecialchars($lugar_torneo); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Fecha de Inscripción:</span>
                    <span class="info-value"><?php echo date('d/m/Y', strtotime($fecha)); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Estatus de la Inscripción:</span>
                    <span class="info-value">
                        <span class="badge <?php echo getEstatusBadge($estatus); ?>">
                            <?php echo ucfirst(htmlspecialchars($estatus)); ?>
                        </span>
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Estado de Pago:</span>
                    <span class="info-value">
                        <span class="badge <?php echo getPagoBadge($pago); ?>">
                            <?php echo getPagoTexto($pago); ?>
                        </span>
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sidebar.js"></script>
</body>
</html>
