<?php
session_start();
// Verificar sesión antes de mostrar el dashboard
include_once("../../controlador/verificar_sesion.php");
include_once("../../modelo/conexion.php");

// Obtener estadísticas según el rol
$stats = [];

try {
    if($_SESSION['rol_ses'] == 'admin' || $_SESSION['rol_ses'] = "entrenador") {
        // Estadísticas completas para admin
        $stats['total_alumnos'] = $conex->query("SELECT COUNT(*) FROM ALUMNO")->fetchColumn();
        $stats['total_entrenadores'] = $conex->query("SELECT COUNT(*) FROM ENTRENADOR")->fetchColumn();
        $stats['total_clases'] = $conex->query("SELECT COUNT(*) FROM CLASE")->fetchColumn();
        $stats['total_torneos'] = $conex->query("SELECT COUNT(*) FROM TORNEO WHERE estatus != 'cancelado'")->fetchColumn();
        $stats['total_representantes'] = $conex->query("SELECT COUNT(*) FROM REPRESENTANTE")->fetchColumn();
        
        // Torneos próximos
        $stats['proximos_torneos'] = $conex->query("SELECT COUNT(*) FROM TORNEO WHERE estatus = 'proximo' AND fecha >= CURDATE()")->fetchColumn();
        
        // Alumnos activos
        $stats['alumnos_activos'] = $conex->query("SELECT COUNT(*) FROM ALUMNO WHERE estatus = 'activo'")->fetchColumn();
        
        // Alumnos por estatus
        $stats['alumnos_inactivos'] = $conex->query("SELECT COUNT(*) FROM ALUMNO WHERE estatus = 'inactivo'")->fetchColumn();
        $stats['alumnos_suspendidos'] = $conex->query("SELECT COUNT(*) FROM ALUMNO WHERE estatus = 'suspendido'")->fetchColumn();
        
        // Últimos alumnos registrados
        $stats['ultimos_alumnos'] = $conex->query("SELECT nombre, apellido, cedula, fechaRegistro, estatus FROM ALUMNO ORDER BY fechaRegistro DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
        
        // Últimos entrenadores registrados
        $stats['ultimos_entrenadores'] = $conex->query("SELECT nombre, apellido, cedula, telefono FROM ENTRENADOR ORDER BY idEntrenador DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
        
        // Alumnos por categoría (resumen)
        $stats['categorias_resumen'] = $conex->query("SELECT categoria, COUNT(*) as total FROM ALUMNO GROUP BY categoria ORDER BY total DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
        
    
    } elseif($_SESSION['rol_ses'] == 'alumno') {
        // Solo obtener datos del alumno para mostrar bienvenida
        $idUsuario = $_SESSION['id_usuario'];
        $alumnoData = $conex->query("SELECT idAlumno, cedula, nombre, apellido, categoria, estatus 
                                    FROM ALUMNO WHERE idUsuario = $idUsuario")->fetch(PDO::FETCH_ASSOC);
        $stats['alumno'] = $alumnoData;
    }
} catch(PDOException $e) {
    error_log("Error en dashboard: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include '../assets/inc/head.php'; ?>
    <style>
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 15px;
            transition: transform 0.2s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            background: #2c3e50;
            flex-shrink: 0;
        }
        .stat-icon.blue { background: #3498db; }
        .stat-icon.green { background: #2ecc71; }
        .stat-icon.orange { background: #f39c12; }
        .stat-icon.purple { background: #9b59b6; }
        .stat-icon.red { background: #e74c3c; }
        .stat-icon.teal { background: #1abc9c; }
        .stat-info h3 {
            margin: 0;
            font-size: 28px;
            font-weight: bold;
        }
        .stat-info p {
            margin: 0;
            color: #7f8c8d;
            font-size: 14px;
        }
        .stat-trend {
            font-size: 12px;
            color: #7f8c8d;
            display: block;
            margin-top: 5px;
        }
        .stat-trend.positive { color: #27ae60; }
        .stat-trend.negative { color: #e74c3c; }
        .stat-trend.neutral { color: #f39c12; }
        
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        .date-badge {
            background: white;
            padding: 10px 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .date-badge i {
            color: #3498db;
            margin-right: 10px;
        }
        .info-section {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .info-section h4 {
            margin-bottom: 15px;
            color: #2c3e50;
            border-bottom: 2px solid #ecf0f1;
            padding-bottom: 10px;
        }
        .info-section h4 i {
            margin-right: 10px;
            color: #3498db;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 12px;
        }
        .badge-success { background: #27ae60; color: white; }
        .badge-warning { background: #f39c12; color: white; }
        .badge-danger { background: #e74c3c; color: white; }
        .badge-secondary { background: #95a5a6; color: white; }
        .badge-info { background: #3498db; color: white; }
        
        .welcome-banner {
            background: linear-gradient(90deg, #2c3e50, #7fcfe6);
            color: white;
            padding: 40px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 30px;
        }
        .welcome-banner h1 {
            font-size: 32px;
            margin-bottom: 10px;
        }
        .welcome-banner p {
            font-size: 18px;
            opacity: 0.9;
        }
        .welcome-banner .chess-icon {
            font-size: 60px;
            margin-bottom: 15px;
        }
        .welcome-banner .btn-white {
            background: white;
            color: #000000ff;
            padding: 10px 30px;
            border-radius: 25px;
            text-decoration: none;
            display: inline-block;
            margin-top: 15px;
            font-weight: bold;
            transition: all 0.3s;
        }
        .welcome-banner .btn-white:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
    </style>
</head>

<body>
<div class="page-container">

    <!-- SIDEBAR -->
    <?php include '../assets/inc/sidebar.php'; ?>

    <!-- HEADER -->
    <?php include '../assets/inc/header.php'; ?>

    <!-- MAIN CONTENT - DASHBOARD -->
    <div class="main-content">
        <!-- Cabecera con título y fecha -->
        <div class="dashboard-header">
            <div>
                <h1 class="page-title">
                    <i class="fas fa-chart-line me-2"></i> 
                    <?php 
                    if($_SESSION['rol_ses'] == 'admin') echo "Panel de Control";
                    elseif($_SESSION['rol_ses'] == 'entrenador') echo "Panel del Entrenador";
                    else echo "Mi Perfil";
                    ?>
                </h1>
                <p class="text-muted mt-1">
                    Bienvenido de nuevo, <?php echo htmlspecialchars($_SESSION['usu_ses'] ?? 'Usuario'); ?>
                    <?php if($_SESSION['rol_ses'] == 'entrenador' && isset($stats['entrenador'])): ?>
                        (<?php echo htmlspecialchars($stats['entrenador']['nombre'] . ' ' . $stats['entrenador']['apellido']); ?>)
                    <?php endif; ?>
                </p>
            </div>
            <div class="date-badge">
                <i class="fas fa-calendar-alt"></i>
                <span id="currentDate"></span>
            </div>
        </div>

        <!-- CONTENIDO SEGÚN ROL -->
        <?php if($_SESSION['rol_ses'] == 'admin' || $_SESSION['rol_ses'] = "entrenador"): ?>
        <!-- ADMIN: Todas las estadísticas -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon green"><i class="fas fa-user-graduate"></i></div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_alumnos'] ?? 0; ?></h3>
                    <p>Total Alumnos</p>
                    <span class="stat-trend positive">
                        <i class="fas fa-user-check"></i> <?php echo $stats['alumnos_activos'] ?? 0; ?> activos
                    </span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon blue"><i class="fas fa-chalkboard-user"></i></div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_entrenadores'] ?? 0; ?></h3>
                    <p>Entrenadores</p>
                    <span class="stat-trend neutral"><i class="fas fa-chess"></i> Activos</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon purple"><i class="fas fa-users"></i></div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_representantes'] ?? 0; ?></h3>
                    <p>Representantes</p>
                    <span class="stat-trend neutral"><i class="fas fa-user-friends"></i> Registrados</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon orange"><i class="fas fa-chess-board"></i></div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_clases'] ?? 0; ?></h3>
                    <p>Clases</p>
                    <span class="stat-trend neutral"><i class="fas fa-calendar"></i> Registradas</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon red"><i class="fas fa-trophy"></i></div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_torneos'] ?? 0; ?></h3>
                    <p>Torneos</p>
                    <span class="stat-trend positive">
                        <i class="fas fa-calendar"></i> <?php echo $stats['proximos_torneos'] ?? 0; ?> próximos
                    </span>
                </div>
            </div>
        </div>

        <!-- Detalle de estatus de alumnos -->
        <div class="info-section">
            <h4><i class="fas fa-chart-bar"></i> Resumen de Alumnos por Estatus</h4>
            <div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));">
                <div class="stat-card" style="border-left: 4px solid #27ae60;">
                    <div class="stat-info">
                        <h3><?php echo $stats['alumnos_activos'] ?? 0; ?></h3>
                        <p>Activos</p>
                    </div>
                </div>
                <div class="stat-card" style="border-left: 4px solid #95a5a6;">
                    <div class="stat-info">
                        <h3><?php echo $stats['alumnos_inactivos'] ?? 0; ?></h3>
                        <p>Inactivos</p>
                    </div>
                </div>
                <div class="stat-card" style="border-left: 4px solid #f39c12;">
                    <div class="stat-info">
                        <h3><?php echo $stats['alumnos_suspendidos'] ?? 0; ?></h3>
                        <p>Suspendidos</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Últimos alumnos registrados -->
        <div class="info-section">
            <h4><i class="fas fa-users"></i> Últimos Alumnos Registrados</h4>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Cédula</th>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Fecha Registro</th>
                            <th>Estatus</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($stats['ultimos_alumnos'])): ?>
                            <?php foreach($stats['ultimos_alumnos'] as $alumno): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($alumno['cedula']); ?></td>
                                <td><?php echo htmlspecialchars($alumno['nombre']); ?></td>
                                <td><?php echo htmlspecialchars($alumno['apellido']); ?></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($alumno['fechaRegistro'])); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $alumno['estatus'] == 'activo' ? 'success' : ($alumno['estatus'] == 'inactivo' ? 'secondary' : 'warning'); ?>">
                                        <?php echo ucfirst($alumno['estatus']); ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="5" class="text-center">No hay alumnos registrados</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Últimos entrenadores -->
        <div class="info-section">
            <h4><i class="fas fa-chalkboard-user"></i> Últimos Entrenadores Registrados</h4>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Cédula</th>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Teléfono</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($stats['ultimos_entrenadores'])): ?>
                            <?php foreach($stats['ultimos_entrenadores'] as $entrenador): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($entrenador['cedula']); ?></td>
                                <td><?php echo htmlspecialchars($entrenador['nombre']); ?></td>
                                <td><?php echo htmlspecialchars($entrenador['apellido']); ?></td>
                                <td><?php echo htmlspecialchars($entrenador['telefono']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="4" class="text-center">No hay entrenadores registrados</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Top categorías -->
        <div class="info-section">
            <h4><i class="fas fa-tags"></i> Top 5 Categorías con más Alumnos</h4>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Categoría</th>
                            <th>Total Alumnos</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($stats['categorias_resumen'])): ?>
                            <?php foreach($stats['categorias_resumen'] as $cat): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($cat['categoria'] ?? 'Sin categoría'); ?></td>
                                <td><?php echo $cat['total']; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="2" class="text-center">No hay categorías registradas</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        
        <?php elseif($_SESSION['rol_ses'] == 'alumno'): ?>
        <!-- ALUMNO: Solo bienvenida -->
        <div class="welcome-banner">
            <div class="chess-icon">♛</div>
            <h1>¡Bienvenido a la Casa del Ajedrez!</h1>
            <p>
                <?php if(isset($stats['alumno'])): ?>
                    <strong><?php echo htmlspecialchars($stats['alumno']['nombre'] . ' ' . $stats['alumno']['apellido']); ?></strong>
                    <br>
                    <span class="badge" style="background: rgba(255,255,255,0.2); color: white; font-size: 14px; margin-top: 10px;">
                        <?php echo htmlspecialchars($stats['alumno']['categoria'] ?? 'Sin categoría'); ?>
                    </span>
                <?php else: ?>
                    Estudiante
                <?php endif; ?>
            </p>
            <p style="font-size: 16px; margin-top: 10px;">
                <i class="fas fa-chess-queen me-2"></i>
                Estamos felices de tenerte en nuestra academia de ajedrez.
            </p>
            <a href="../../controlador/ctl_alumno.php?L=lis" class="btn-white">
                <i class="fas fa-user me-2"></i> Ver listado de alumnos
            </a>
        </div>

        <!-- Información adicional para el alumno -->
        <div class="info-section">
            <h4><i class="fas fa-info-circle"></i> Información de la Academia</h4>
            <div class="row">
                <div class="col-md-6">
                    <p><i class="fas fa-clock text-primary me-2"></i> <strong>Horarios:</strong> Lunes a Viernes</p>
                    <p><i class="fas fa-map-marker-alt text-primary me-2"></i> <strong>Ubicación:</strong> Casa del Ajedrez</p>
                </div>
                <div class="col-md-6">
                    <p><i class="fas fa-phone text-primary me-2"></i> <strong>Contacto:</strong> MN Marcos Pérez</p>
                    <p><i class="fas fa-envelope text-primary me-2"></i> <strong>Email:</strong> info@casadelajedrez.com</p>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- INCLUIR FLASH PARA MOSTRAR MENSAJES -->
<?php include '../assets/inc/flash.php'; ?>

<!-- Scripts -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sweetalert2.all.min.js"></script>
<script src="../assets/js/sidebar.js"></script>

<script>
// Mostrar fecha actual
document.getElementById('currentDate').textContent = new Date().toLocaleDateString('es-VE', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
});
</script>

</body>
</html>