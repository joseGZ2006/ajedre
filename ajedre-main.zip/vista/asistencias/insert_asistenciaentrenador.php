<?php
session_start();
// Verificar sesión antes de mostrar el dashboard
include_once("../../controlador/verificar_sesion.php");
include("../../modelo/conexion.php");

try {
    $stmt = $conex->prepare("SELECT idEntrenador, cedula, nombre, apellido FROM ENTRENADOR ORDER BY apellido ASC, nombre ASC");
    $stmt->execute();
    $entrenadores = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $entrenadores = [];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include '../assets/inc/head.php'; ?>
</head>

<body>
<div class="page-container">

    <!-- SIDEBAR -->
    <?php include '../assets/inc/sidebar.php'; ?>

    <!-- HEADER -->
    <?php include '../assets/inc/header.php'; ?>

    <!-- MAIN -->
    <div class="main-content">

        <div class="catalog-header">
            <h1 class="page-title">
                <i class="fas fa-clipboard-list me-2"></i> REGISTRAR ASISTENCIA ENTRENADOR
            </h1>

            <a href="./asistencia.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-2"></i> Volver
            </a>
        </div>

        <div class="form-card">

            <form method="POST" action="../../controlador/ctl_asistencia_entrenador.php" onsubmit="return validarAsistenciaEntrenador(event)">
                <input type="hidden" name="registrar" value="registrar">

                <h3 class="section-title">Datos de Asistencia</h3>

                <!-- ENTRENADOR -->
                <div class="mb-3">
                    <label class="form-label required-star">Entrenador</label>
                    <select class="form-select" id="idEntrenador" name="idEntrenador" required>
                        <option value="">Seleccionar entrenador</option>
                        <?php foreach($entrenadores as $e): ?>
                            <option value="<?php echo $e['idEntrenador']; ?>">
                                <?php echo htmlspecialchars($e['cedula'].' - '.$e['nombre'].' '.$e['apellido']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback-real" id="idEntrenadorFeedback"></div>
                </div>

                <!-- FECHA -->
                <div class="mb-3">
                    <label class="form-label required-star">Fecha</label>
                    <input type="date" class="form-control" id="fecha" name="fecha" required>
                    <div class="invalid-feedback-real" id="fechaFeedback"></div>
                </div>

                <!-- HORA -->
                <div class="mb-3">
                    <label class="form-label required-star">Hora</label>
                    <input type="text" class="form-control" id="hora" name="horaEntrada" placeholder="Ej: 09:00 AM" required>
                    <div class="invalid-feedback-real" id="horaFeedback"></div>
                </div>

                <!-- ALUMNOS ENTRENADOS -->
                <div class="mb-3">
                    <label class="form-label required-star">Alumnos entrenados</label>
                    <input type="number" min="0" class="form-control" id="alumnosEntrenados" name="alumnosEntrenados" placeholder="Cantidad" required>
                    <div class="invalid-feedback-real" id="alumnosEntrenadosFeedback"></div>
                </div>

                <!-- OBSERVACIÓN -->
                <div class="mb-3">
                    <label class="form-label">Observación</label>
                    <textarea class="form-control" id="observacion" name="observacion" placeholder="Escriba la observación (opcional)"></textarea>
                    <div class="invalid-feedback-real" id="observacionFeedback"></div>
                </div>

                <!-- BOTONES -->
                <div class="form-actions">
                    <button type="reset" class="btn btn-danger" id="resetBtn">
                        <i class="fas fa-eraser me-2"></i> Limpiar
                    </button>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i> Registrar
                    </button>
                </div>

            </form>

        </div>

    </div>

</div>

<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sweetalert2.all.min.js"></script>
<script src="../assets/js/sidebar.js"></script>
<script src="../assets/js/validar_asistenciaentrenador.js"></script>

</body>
</html>