<?php
class Clase {

    ## REGISTRAR
    public function RegistrarClase($idAlumno, $idEntrenador, $idHorarioClase, $fechaInicio, $fechaFin) {
        include("conexion.php");
        if (empty($idAlumno) || !is_numeric($idAlumno))
            return ['success' => false, 'error' => 'Alumno inválido.'];
        if (empty($idEntrenador) || !is_numeric($idEntrenador))
            return ['success' => false, 'error' => 'Entrenador inválido.'];
        if (empty($idHorarioClase) || !is_numeric($idHorarioClase))
            return ['success' => false, 'error' => 'Horario inválido.'];
        if (empty($fechaInicio))
            return ['success' => false, 'error' => 'La fecha de inicio es requerida.'];
        try {
            $sql = $conex->prepare("INSERT INTO CLASE (idAlumno, idEntrenador, idHorarioClase, fechaInicio, fechaFin) VALUES (?, ?, ?, ?, ?)");
            $ok  = $sql->execute([$idAlumno, $idEntrenador, $idHorarioClase, $fechaInicio, $fechaFin ?: null]);
            return $ok ? ['success' => true, 'id' => $conex->lastInsertId()] : ['success' => false, 'error' => 'Error al registrar.'];
        } catch (PDOException $e) {
            error_log("Error RegistrarClase: " . $e->getMessage());
            return ['success' => false, 'error' => 'Error en la base de datos.'];
        }
    }

    ## LISTAR
    public function ListarClases() {
        include("conexion.php");
        try {
            $sql = $conex->prepare("
                SELECT c.*,
                       a.nombre AS nombre_alumno, a.apellido AS apellido_alumno, a.cedula AS cedula_alumno,
                       e.nombre AS nombre_entrenador, e.apellido AS apellido_entrenador,
                       h.diaSemana, h.horaInicio, h.horaFin
                FROM CLASE c
                LEFT JOIN ALUMNO       a ON c.idAlumno       = a.idAlumno
                LEFT JOIN ENTRENADOR   e ON c.idEntrenador   = e.idEntrenador
                LEFT JOIN HORARIO_CLASE h ON c.idHorarioClase = h.idHorarioClase
                ORDER BY c.idClase DESC
            ");
            $sql->execute();
            return $sql->rowCount() > 0 ? $sql->fetchAll(PDO::FETCH_ASSOC) : false;
        } catch (PDOException $e) {
            error_log("Error ListarClases: " . $e->getMessage());
            return false;
        }
    }

    ## CONSULTAR
    public function ConsultarClase($id) {
        include("conexion.php");
        try {
            $sql = $conex->prepare("
                SELECT c.*,
                       a.nombre AS nombre_alumno, a.apellido AS apellido_alumno, a.cedula AS cedula_alumno,
                       e.nombre AS nombre_entrenador, e.apellido AS apellido_entrenador, e.cedula AS cedula_entrenador,
                       h.diaSemana, h.horaInicio, h.horaFin
                FROM CLASE c
                LEFT JOIN ALUMNO       a ON c.idAlumno       = a.idAlumno
                LEFT JOIN ENTRENADOR   e ON c.idEntrenador   = e.idEntrenador
                LEFT JOIN HORARIO_CLASE h ON c.idHorarioClase = h.idHorarioClase
                WHERE c.idClase = ?
            ");
            $sql->execute([$id]);
            return $sql->rowCount() > 0 ? $sql->fetch(PDO::FETCH_ASSOC) : false;
        } catch (PDOException $e) {
            error_log("Error ConsultarClase: " . $e->getMessage());
            return false;
        }
    }

    ## ACTUALIZAR
    public function ActualizarClase($id, $idAlumno, $idEntrenador, $idHorarioClase, $fechaInicio, $fechaFin) {
        include("conexion.php");
        if (empty($idAlumno) || !is_numeric($idAlumno))
            return ['success' => false, 'error' => 'Alumno inválido.'];
        if (empty($idEntrenador) || !is_numeric($idEntrenador))
            return ['success' => false, 'error' => 'Entrenador inválido.'];
        if (empty($idHorarioClase) || !is_numeric($idHorarioClase))
            return ['success' => false, 'error' => 'Horario inválido.'];
        if (empty($fechaInicio))
            return ['success' => false, 'error' => 'La fecha de inicio es requerida.'];
        try {
            $sql = $conex->prepare("UPDATE CLASE SET idAlumno=?, idEntrenador=?, idHorarioClase=?, fechaInicio=?, fechaFin=? WHERE idClase=?");
            $ok  = $sql->execute([$idAlumno, $idEntrenador, $idHorarioClase, $fechaInicio, $fechaFin ?: null, $id]);
            return $ok ? ['success' => true] : ['success' => false, 'error' => 'Error al actualizar.'];
        } catch (PDOException $e) {
            error_log("Error ActualizarClase: " . $e->getMessage());
            return ['success' => false, 'error' => 'Error en la base de datos.'];
        }
    }

    ## ELIMINAR
    public function EliminarClase($id) {
        include("conexion.php");
        try {
            $sql = $conex->prepare("DELETE FROM CLASE WHERE idClase = ?");
            $ok  = $sql->execute([$id]);
            return $ok ? ['success' => true] : ['success' => false, 'error' => 'Error al eliminar.'];
        } catch (PDOException $e) {
            error_log("Error EliminarClase: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}
?>
