<?php
session_start();
// Verificar sesión antes de mostrar el dashboard
include_once("../../controlador/verificar_sesion.php");
include_once("../../modelo/clase_asistencia_alumno.php");
include_once("../../modelo/clase_asistencia_entrenador.php");

$asistAluObj = new AsistenciaAlumno();
$asistEntObj = new AsistenciaEntrenador();

$listaAlu = $asistAluObj->ListarAsistenciasAlumno();
$listaEnt = $asistEntObj->ListarAsistenciasEntrenador();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include '../assets/inc/head.php'; ?>
</head>

<body>
<div class="page-container">

    <!-- SIDEBAR -->
    <?php include '../assets/inc/sidebar.php'; ?>

    <!-- HEADER -->
    <?php include '../assets/inc/header.php'; ?>

      

    <!-- MAIN -->
    <div class="main-content">

        <!-- HEADER DEL MÓDULO -->
        <div class="catalog-header">

            <h1 class="page-title">
                <i class="fas fa-clipboard-list me-2"></i> ASISTENCIA
            </h1>

            <!-- RADIOS PRO -->
            <div style="display:flex;gap:15px;align-items:center">

                <label>
                    <input type="radio" name="tipo" value="entrenador" checked>
                    Entrenadores
                </label>

                <label>
                    <input type="radio" name="tipo" value="alumno">
                    Alumnos
                </label>

            </div>

            <a id="btnRegistrar" href="insert_asistenciaentrenador.php" class="btn btn-custom">
                <i class="fas fa-plus-circle me-2"></i> Nueva Asistencia
            </a>

        </div>

        <!-- TABLA ENTRENADOR -->
        <div class="table-responsive" id="tablaEntrenador">

            <table class="table alumno-table">

                <thead>
                    <tr>
                        <th>Entrenador</th>
                        <th>Fecha</th>
                        <th>Hora Entrada</th>
                        <th>Alumnos Entrenados</th>
                        <th>Observación</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if ($listaEnt && count($listaEnt) > 0): ?>
                        <?php foreach ($listaEnt as $e): ?>
                            <tr>
                                <td><?php echo htmlspecialchars(($e['nombre_entrenador'] ?? '') . ' ' . ($e['apellido_entrenador'] ?? '')); ?></td>
                                <td><?php echo htmlspecialchars($e['fecha']); ?></td>
                                <td><?php echo htmlspecialchars($e['horaEntrada'] ? date("h:i A", strtotime($e['horaEntrada'])) : ''); ?></td>
                                <td><?php echo htmlspecialchars($e['alumnosEntrenados'] ?? '0'); ?></td>
                                <td><?php echo htmlspecialchars($e['observacion'] ?? ''); ?></td>
                                <td>
                                    <a class="btn btn-sm btn-secondary" href="../../controlador/ctl_asistencia_entrenador.php?C=con&I=<?php echo $e['idAsistenciaEntrenador']; ?>"><i class="fas fa-eye"></i></a>
                                    <?php if($_SESSION['rol_ses'] == 'admin'){  ?>
                                    <a class="btn btn-sm btn-primary" href="../../controlador/ctl_asistencia_entrenador.php?M=mos&I=<?php echo $e['idAsistenciaEntrenador']; ?>"><i class="fas fa-edit"></i></a>
                                    <button class="btn btn-sm btn-danger btn-delete" data-tipo="entrenador" data-id="<?php echo $e['idAsistenciaEntrenador']; ?>" data-nombre="<?php echo htmlspecialchars(($e['nombre_entrenador'] ?? '') . ' ' . ($e['apellido_entrenador'] ?? '')); ?>">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">No hay registros de asistencia de entrenadores</td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>

        </div>

        <!-- TABLA ALUMNOS -->
        <div class="table-responsive" id="tablaAlumno" style="display:none">

            <table class="table alumno-table">

                <thead>
                    <tr>
                        <th>Alumno</th>
                        <th>Fecha</th>
                        <th>Hora Entrada</th>
                        <th>Estatus</th>
                        <th>Observación</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if ($listaAlu && count($listaAlu) > 0): ?>
                        <?php foreach ($listaAlu as $a): ?>
                            <tr>
                                <td><?php echo htmlspecialchars(($a['nombre_alumno'] ?? '') . ' ' . ($a['apellido_alumno'] ?? '')); ?></td>
                                <td><?php echo htmlspecialchars($a['fecha']); ?></td>
                                <td><?php echo htmlspecialchars($a['horaEntrada'] ? date("h:i A", strtotime($a['horaEntrada'])) : ''); ?></td>
                                <td>
                                    <?php 
                                    $badgeClass = 'bg-secondary';
                                    if ($a['estatus'] == 'presente') $badgeClass = 'bg-success';
                                    elseif ($a['estatus'] == 'ausente') $badgeClass = 'bg-danger';
                                    elseif ($a['estatus'] == 'tarde') $badgeClass = 'bg-warning text-dark';
                                    elseif ($a['estatus'] == 'justificado') $badgeClass = 'bg-info text-dark';
                                    ?>
                                    <span class="badge <?php echo $badgeClass; ?>">
                                        <?php echo ucfirst(htmlspecialchars($a['estatus'])); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($a['observacion'] ?? ''); ?></td>
                                <td>
                                    <a class="btn btn-sm btn-secondary" href="../../controlador/ctl_asistencia_alumno.php?C=con&I=<?php echo $a['idAsistenciaAlumno']; ?>"><i class="fas fa-eye"></i></a>
                                    <?php if($_SESSION['rol_ses'] == 'admin'){  ?>
                                    <a class="btn btn-sm btn-primary" href="../../controlador/ctl_asistencia_alumno.php?M=mos&I=<?php echo $a['idAsistenciaAlumno']; ?>"><i class="fas fa-edit"></i></a>
                                    <button class="btn btn-sm btn-danger btn-delete" data-tipo="alumno" data-id="<?php echo $a['idAsistenciaAlumno']; ?>" data-nombre="<?php echo htmlspecialchars(($a['nombre_alumno'] ?? '') . ' ' . ($a['apellido_alumno'] ?? '')); ?>">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">No hay registros de asistencia de alumnos</td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>

        </div>

    </div>

</div>

<?php include '../assets/inc/flash.php'; ?>
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sidebar.js"></script>
<script src="../assets/js/sweetalert2.all.min.js"></script>

<!-- JS CONTROLADOR -->
<script>
document.addEventListener("DOMContentLoaded", function () {

    const radios = document.querySelectorAll("input[name='tipo']");
    const tablaEntrenador = document.getElementById("tablaEntrenador");
    const tablaAlumno = document.getElementById("tablaAlumno");
    const btn = document.getElementById("btnRegistrar");

    function cambiar(tipo){

        if(tipo === "entrenador"){
            tablaEntrenador.style.display = "block";
            tablaAlumno.style.display = "none";
            btn.href = "insert_asistenciaentrenador.php";
            const rad = document.querySelector("input[name='tipo'][value='entrenador']");
            if (rad) rad.checked = true;
        }

        if(tipo === "alumno"){
            tablaEntrenador.style.display = "none";
            tablaAlumno.style.display = "block";
            btn.href = "insert_asistenciaalumnos.php";
            const rad = document.querySelector("input[name='tipo'][value='alumno']");
            if (rad) rad.checked = true;
        }
        localStorage.setItem('asistencia_tab', tipo);
    }

    radios.forEach(r => {
        r.addEventListener("change", function(){
            cambiar(this.value);
        });
    });

    const tabGuardado = localStorage.getItem('asistencia_tab') || 'entrenador';
    cambiar(tabGuardado);

    // SweetAlert Deletion
    const botonesEliminar = document.querySelectorAll('.btn-delete');
    botonesEliminar.forEach((boton) => {
        boton.addEventListener('click', function(e) {
            e.preventDefault();
            const nombre = this.getAttribute('data-nombre');
            const id = this.getAttribute('data-id');
            const tipo = this.getAttribute('data-tipo');
            
            Swal.fire({
                title: '¿Eliminar asistencia?',
                text: `¿Estás seguro de que deseas eliminar la asistencia de "${nombre}"?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Sí, eliminar',
                cancelButtonText: 'Cancelar',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    const ctl = tipo === "alumno" ? "ctl_asistencia_alumno" : "ctl_asistencia_entrenador";
                    window.location.href = `../../controlador/${ctl}.php?E=eli&I=${btoa(id)}`;
                }
            });
        });
    });

});
</script>

</body>
</html>