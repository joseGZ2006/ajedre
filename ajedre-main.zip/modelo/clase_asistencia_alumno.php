<?php
class AsistenciaAlumno {

    private $estatusPermitidos = ['presente','ausente','tarde','justificado'];

    ## REGISTRAR
    public function RegistrarAsistenciaAlumno($idAsignacionClase, $fecha, $horaEntrada, $horaSalida, $estatus, $observacion) {
        include("conexion.php");
        if (empty($idAsignacionClase) || !is_numeric($idAsignacionClase))
            return ['success' => false, 'error' => 'Clase no válida.'];
        if (empty($fecha))
            return ['success' => false, 'error' => 'La fecha es requerida.'];
        if (!in_array($estatus, $this->estatusPermitidos))
            return ['success' => false, 'error' => 'Estatus no válido.'];
        try {
            $sql = $conex->prepare("INSERT INTO ASISTENCIA_ALUMNO (idAsignacionClase, fecha, horaEntrada, horaSalida, estatus, observacion) VALUES (?, ?, ?, ?, ?, ?)");
            $ok  = $sql->execute([$idAsignacionClase, $fecha, $horaEntrada ?: null, $horaSalida ?: null, $estatus, $observacion ?: null]);
            return $ok ? ['success' => true] : ['success' => false, 'error' => 'Error al registrar.'];
        } catch (PDOException $e) {
            error_log("Error RegistrarAsistenciaAlumno: " . $e->getMessage());
            return ['success' => false, 'error' => 'Error en la base de datos.'];
        }
    }

    ## LISTAR
    public function ListarAsistenciasAlumno() {
        include("conexion.php");
        try {
            $sql = $conex->prepare("
                SELECT aa.*,
                       a.nombre AS nombre_alumno, a.apellido AS apellido_alumno, a.cedula AS cedula_alumno,
                       h.diaSemana, h.horaInicio, h.horaFin
                FROM ASISTENCIA_ALUMNO aa
                LEFT JOIN CLASE c         ON aa.idAsignacionClase = c.idClase
                LEFT JOIN ALUMNO a         ON c.idAlumno          = a.idAlumno
                LEFT JOIN HORARIO_CLASE h  ON c.idHorarioClase    = h.idHorarioClase
                ORDER BY aa.fecha DESC, aa.idAsistenciaAlumno DESC
            ");
            $sql->execute();
            return $sql->rowCount() > 0 ? $sql->fetchAll(PDO::FETCH_ASSOC) : false;
        } catch (PDOException $e) {
            error_log("Error ListarAsistenciasAlumno: " . $e->getMessage());
            return false;
        }
    }

    ## CONSULTAR
    public function ConsultarAsistenciaAlumno($id) {
        include("conexion.php");
        try {
            $sql = $conex->prepare("
                SELECT aa.*,
                       a.nombre AS nombre_alumno, a.apellido AS apellido_alumno, a.cedula AS cedula_alumno,
                       h.diaSemana, h.horaInicio, h.horaFin
                FROM ASISTENCIA_ALUMNO aa
                LEFT JOIN CLASE c         ON aa.idAsignacionClase = c.idClase
                LEFT JOIN ALUMNO a         ON c.idAlumno          = a.idAlumno
                LEFT JOIN HORARIO_CLASE h  ON c.idHorarioClase    = h.idHorarioClase
                WHERE aa.idAsistenciaAlumno = ?
            ");
            $sql->execute([$id]);
            return $sql->rowCount() > 0 ? $sql->fetch(PDO::FETCH_ASSOC) : false;
        } catch (PDOException $e) {
            error_log("Error ConsultarAsistenciaAlumno: " . $e->getMessage());
            return false;
        }
    }

    ## ACTUALIZAR
    public function ActualizarAsistenciaAlumno($id, $idAsignacionClase, $fecha, $horaEntrada, $horaSalida, $estatus, $observacion) {
        include("conexion.php");
        if (empty($idAsignacionClase) || !is_numeric($idAsignacionClase))
            return ['success' => false, 'error' => 'Clase no válida.'];
        if (empty($fecha))
            return ['success' => false, 'error' => 'La fecha es requerida.'];
        if (!in_array($estatus, $this->estatusPermitidos))
            return ['success' => false, 'error' => 'Estatus no válido.'];
        try {
            $sql = $conex->prepare("UPDATE ASISTENCIA_ALUMNO SET idAsignacionClase=?, fecha=?, horaEntrada=?, horaSalida=?, estatus=?, observacion=? WHERE idAsistenciaAlumno=?");
            $ok  = $sql->execute([$idAsignacionClase, $fecha, $horaEntrada ?: null, $horaSalida ?: null, $estatus, $observacion ?: null, $id]);
            return $ok ? ['success' => true] : ['success' => false, 'error' => 'Error al actualizar.'];
        } catch (PDOException $e) {
            error_log("Error ActualizarAsistenciaAlumno: " . $e->getMessage());
            return ['success' => false, 'error' => 'Error en la base de datos.'];
        }
    }

    ## ELIMINAR
    public function EliminarAsistenciaAlumno($id) {
        include("conexion.php");
        try {
            $sql = $conex->prepare("DELETE FROM ASISTENCIA_ALUMNO WHERE idAsistenciaAlumno = ?");
            $ok  = $sql->execute([$id]);
            return $ok ? ['success' => true] : ['success' => false, 'error' => 'Error al eliminar.'];
        } catch (PDOException $e) {
            error_log("Error EliminarAsistenciaAlumno: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}
?>
