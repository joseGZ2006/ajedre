<?php
session_start();
include("../modelo/conexion.php");
include("../modelo/clase_inscripcion_alumno.php");

$inscripcion = new InscripcionAlumno();

// Función para validar fecha
function validarFechaInscripcion($fecha) {
    if(empty($fecha)) {
        return false;
    }
    $fechaObj = DateTime::createFromFormat('Y-m-d', $fecha);
    return $fechaObj && $fechaObj->format('Y-m-d') === $fecha;
}

// Función para validar estatus
function validarEstatusInscripcion($estatus) {
    $estatusPermitidos = ['activo', 'inactivo', 'suspendido'];
    return in_array($estatus, $estatusPermitidos);
}

############################################################################
### REGISTRAR ##############################################################
############################################################################
if(isset($_POST['registrar']) && $_POST['registrar'] == "registrar"){
    $errores = [];
    $idAlumno = isset($_POST['idAlumno']) ? $_POST['idAlumno'] : '';
    $fecha = isset($_POST['fecha']) ? trim($_POST['fecha']) : '';
    $estatus = isset($_POST['estatus']) ? $_POST['estatus'] : '';
    
    if(empty($idAlumno) || !is_numeric($idAlumno)) {
        $errores[] = "Debe seleccionar un alumno válido";
    }
    
    if(empty($fecha)) {
        $errores[] = "La fecha de inscripción es requerida";
    } elseif(!validarFechaInscripcion($fecha)) {
        $errores[] = "La fecha de inscripción no es válida (formato YYYY-MM-DD)";
    }
    
    if(empty($estatus)) {
        $errores[] = "El estatus es requerido";
    } elseif(!validarEstatusInscripcion($estatus)) {
        $errores[] = "El estatus seleccionado no es válido";
    }
    
    if(!empty($errores)) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error de Validación', 'text' => implode('<br>', $errores)];
        header("Location: ../vista/inscripcion_alumno/insert_inscripcion_alumno.php");
        exit;
    }
    
    $resultado = $inscripcion->RegistrarInscripcionAlumno($idAlumno, $fecha, $estatus);
    
    if($resultado['success']){ 
        $_SESSION['flash'] = ['icon' => 'success', 'title' => 'Éxito', 'text' => 'Inscripción de Alumno registrada con éxito.'];
        header("Location: ../vista/inscripcion_alumno/inscripcion_alumno.php");
        exit;
    } else {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => $resultado['error']];
        header("Location: ../vista/inscripcion_alumno/insert_inscripcion_alumno.php");
        exit;
    }
}

############################################################################
### LISTAR #################################################################
############################################################################
if(isset($_GET['L']) && $_GET['L'] == "lis"){
    header("Location: ../vista/inscripcion_alumno/inscripcion_alumno.php");
    exit;
}

#############################################################################
### CONSULTAR (VER DETALLE) #################################################
#############################################################################
if(isset($_GET['C']) && $_GET['C'] == "con"){
    if(!isset($_GET['I'])) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'ID de inscripción no proporcionado.'];
        header("Location: ../vista/inscripcion_alumno/inscripcion_alumno.php");
        exit;
    }
    
    $id = $_GET['I'];
    
    if(!is_numeric($id)) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'ID de inscripción inválido.'];
        header("Location: ../vista/inscripcion_alumno/inscripcion_alumno.php");
        exit;
    }
    
    $datos = $inscripcion->ConsultarInscripcionAlumno($id);
    
    if($datos === false){
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'No se encontró la inscripción solicitada.'];
        header("Location: ../vista/inscripcion_alumno/inscripcion_alumno.php");
        exit;
    } else {
        $idEncoded = base64_encode($datos['idInscripcionAlumno']);
        $nombreAlumnoEncoded = base64_encode($datos['nombre_alumno'] . ' ' . $datos['apellido_alumno']);
        $cedulaAlumnoEncoded = base64_encode($datos['cedula_alumno']);
        $clubAlumnoEncoded = base64_encode($datos['club_alumno'] ?? 'N/A');
        $fechaInscripcionEncoded = base64_encode($datos['fecha']);
        $estatusEncoded = base64_encode($datos['estatus']);
        $correoAlumnoEncoded = base64_encode($datos['correo_alumno'] ?? 'N/A');
        $telefonoAlumnoEncoded = base64_encode($datos['telefono_alumno'] ?? 'N/A');
        
        header("Location: ../vista/inscripcion_alumno/detalle_inscripcion_alumno.php?id=$idEncoded&alumno=$nombreAlumnoEncoded&cedula=$cedulaAlumnoEncoded&club=$clubAlumnoEncoded&fecha=$fechaInscripcionEncoded&estatus=$estatusEncoded&correo=$correoAlumnoEncoded&telefono=$telefonoAlumnoEncoded");
        exit;
    }
}

############################################################################
### MOSTRAR PARA EDITAR ####################################################
############################################################################
if(isset($_GET['M']) && $_GET['M'] == "mos"){
    if(!isset($_GET['I'])) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'ID de inscripción no proporcionado.'];
        header("Location: ../vista/inscripcion_alumno/inscripcion_alumno.php");
        exit;
    }
    
    $id = $_GET['I'];
    
    if(!is_numeric($id)) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'ID de inscripción inválido.'];
        header("Location: ../vista/inscripcion_alumno/inscripcion_alumno.php");
        exit;
    }
    
    $datos = $inscripcion->MostrarInscripcionAlumno($id);
    
    if($datos === false){
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'No se encontró la inscripción solicitada.'];
        header("Location: ../vista/inscripcion_alumno/inscripcion_alumno.php");
        exit;
    } else {
        $idEncoded = base64_encode($datos['idInscripcionAlumno']);
        $idAlumnoEncoded = base64_encode($datos['idAlumno']);
        $fechaEncoded = base64_encode($datos['fecha']);
        $estatusEncoded = base64_encode($datos['estatus']);
        
        header("Location: ../vista/inscripcion_alumno/edit_inscripcion_alumno.php?id=$idEncoded&alumno=$idAlumnoEncoded&fecha=$fechaEncoded&estatus=$estatusEncoded");
        exit;
    }
}

############################################################################
### ACTUALIZAR #############################################################
############################################################################
if(isset($_POST['actualizar']) && $_POST['actualizar'] == "actualizar"){
    $errores = [];
    $idAlumno = isset($_POST['idAlumno']) ? $_POST['idAlumno'] : '';
    $fecha = isset($_POST['fecha']) ? trim($_POST['fecha']) : '';
    $estatus = isset($_POST['estatus']) ? $_POST['estatus'] : '';
    
    if(empty($idAlumno) || !is_numeric($idAlumno)) {
        $errores[] = "Debe seleccionar un alumno válido";
    }
    
    if(empty($fecha)) {
        $errores[] = "La fecha de inscripción es requerida";
    } elseif(!validarFechaInscripcion($fecha)) {
        $errores[] = "La fecha de inscripción no es válida (formato YYYY-MM-DD)";
    }
    
    if(empty($estatus)) {
        $errores[] = "El estatus es requerido";
    } elseif(!validarEstatusInscripcion($estatus)) {
        $errores[] = "El estatus seleccionado no es válido";
    }
    
    if(!empty($errores)) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error de Validación', 'text' => implode('<br>', $errores)];
        $idParam = isset($_POST['id']) ? $_POST['id'] : '';
        $alumnoParam = isset($_POST['alumno_original']) ? $_POST['alumno_original'] : '';
        $fechaParam = isset($_POST['fecha_original']) ? $_POST['fecha_original'] : '';
        $estatusParam = isset($_POST['estatus_original']) ? $_POST['estatus_original'] : '';
        header("Location: ../vista/inscripcion_alumno/edit_inscripcion_alumno.php?id=$idParam&alumno=$alumnoParam&fecha=$fechaParam&estatus=$estatusParam");
        exit;
    }
    
    $id = base64_decode($_POST['id']);
    $resultado = $inscripcion->ActualizarInscripcionAlumno($id, $idAlumno, $fecha, $estatus);
    
    if($resultado['success']){ 
        $_SESSION['flash'] = ['icon' => 'success', 'title' => 'Éxito', 'text' => 'Inscripción de Alumno actualizada con éxito.'];
        header("Location: ../vista/inscripcion_alumno/inscripcion_alumno.php");
        exit;
    } else {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => $resultado['error']];
        $idParam = isset($_POST['id']) ? $_POST['id'] : '';
        $alumnoParam = isset($_POST['alumno_original']) ? $_POST['alumno_original'] : '';
        $fechaParam = isset($_POST['fecha_original']) ? $_POST['fecha_original'] : '';
        $estatusParam = isset($_POST['estatus_original']) ? $_POST['estatus_original'] : '';
        header("Location: ../vista/inscripcion_alumno/edit_inscripcion_alumno.php?id=$idParam&alumno=$alumnoParam&fecha=$fechaParam&estatus=$estatusParam");
        exit;
    }
}

############################################################################
### ELIMINAR ###############################################################
############################################################################
if(isset($_GET['E']) && $_GET['E'] == "eli"){
    if(!isset($_GET['I'])) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'ID de inscripción no proporcionado.'];
        header("Location: ../vista/inscripcion_alumno/inscripcion_alumno.php");
        exit;
    }
    
    $id = base64_decode($_GET['I']);
    
    if(!is_numeric($id)) {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'ID de inscripción inválido.'];
        header("Location: ../vista/inscripcion_alumno/inscripcion_alumno.php");
        exit;
    }
    
    $resultado = $inscripcion->EliminarInscripcionAlumno($id);
    
    if($resultado['success']){
        $_SESSION['flash'] = ['icon' => 'success', 'title' => 'Éxito', 'text' => 'Inscripción de Alumno eliminada con éxito.'];
    } else {
        $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => $resultado['error']];
    }
    
    header("Location: ../vista/inscripcion_alumno/inscripcion_alumno.php");
    exit;
}

############################################################################
### TOGGLE ESTATUS (AJAX) ##################################################
############################################################################
if(isset($_POST['T']) && $_POST['T'] == "tog"){
    header('Content-Type: application/json');

    $id = isset($_POST['id']) ? $_POST['id'] : '';
    $estatusActual = isset($_POST['estatus']) ? $_POST['estatus'] : '';

    if(empty($id) || !is_numeric($id)){
        echo json_encode(['success' => false, 'error' => 'ID inválido.']);
        exit;
    }

    // Alternar entre activo y suspendido
    $nuevoEstatus = ($estatusActual === 'activo') ? 'suspendido' : 'activo';

    $resultado = $inscripcion->CambiarEstatusInscripcionAlumno($id, $nuevoEstatus);
    echo json_encode($resultado);
    exit;
}
?>
