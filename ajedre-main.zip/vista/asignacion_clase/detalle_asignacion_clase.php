<?php
session_start();
include_once("../../controlador/verificar_sesion.php");

$id          = isset($_GET['id'])         ? base64_decode($_GET['id'])          : '';
$alumno      = isset($_GET['alumno'])     ? base64_decode($_GET['alumno'])       : '';
$cedula      = isset($_GET['cedula'])     ? base64_decode($_GET['cedula'])       : '';
$entrenador  = isset($_GET['entrenador']) ? base64_decode($_GET['entrenador'])   : '';
$dia         = isset($_GET['dia'])        ? base64_decode($_GET['dia'])          : '';
$hi          = isset($_GET['hi'])         ? base64_decode($_GET['hi'])           : '';
$hf          = isset($_GET['hf'])         ? base64_decode($_GET['hf'])           : '';
$fechaInicio = isset($_GET['fi'])         ? base64_decode($_GET['fi'])           : '';
$fechaFin    = isset($_GET['ff'])         ? base64_decode($_GET['ff'])           : '';

if(empty($id)){ $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'Clase no encontrada.']; header("Location: ./asignacion_clase.php"); exit; }
?>
<!DOCTYPE html>
<html lang="es">
<head><?php include '../assets/inc/head.php'; ?></head>
<body>
<div class="page-container">
    <?php include '../assets/inc/sidebar.php'; ?>
    <?php include '../assets/inc/header.php'; ?>

    <div class="main-content">
        <div class="detail-header">
            <div class="catalog-header">
                <h1 class="page-title"><i class="fas fa-chalkboard-teacher me-2"></i> Detalle de Asignación de Clase</h1>
            </div>
            <a href="./asignacion_clase.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-2"></i>Volver</a>
        </div>

        <div class="detail-avatar">
            <div class="avatar-large"><i class="fas fa-user-graduate"></i></div>
            <h2><?php echo htmlspecialchars($alumno); ?></h2>
            <p class="text-muted">Cédula: <?php echo htmlspecialchars($cedula); ?> | ID Clase: <?php echo htmlspecialchars($id); ?></p>
        </div>

        <div class="detail-info-grid">
            <div class="info-group">
                <label><i class="fas fa-user-graduate me-2"></i>Alumno</label>
                <div class="info-row"><span class="info-label">Nombre:</span><span class="info-value"><?php echo htmlspecialchars($alumno); ?></span></div>
                <div class="info-row"><span class="info-label">Cédula:</span><span class="info-value"><?php echo htmlspecialchars($cedula); ?></span></div>
            </div>
            <div class="info-group">
                <label><i class="fas fa-dumbbell me-2"></i>Entrenador</label>
                <div class="info-row"><span class="info-label">Nombre:</span><span class="info-value"><?php echo htmlspecialchars($entrenador); ?></span></div>
            </div>
            <div class="info-group">
                <label><i class="fas fa-clock me-2"></i>Horario</label>
                <div class="info-row"><span class="info-label">Día:</span><span class="info-value"><?php echo htmlspecialchars($dia); ?></span></div>
                <div class="info-row"><span class="info-label">Hora:</span><span class="info-value"><?php echo $hi ? date('h:i A',strtotime($hi)) : 'N/A'; ?> - <?php echo $hf ? date('h:i A',strtotime($hf)) : 'N/A'; ?></span></div>
            </div>
            <div class="info-group">
                <label><i class="fas fa-calendar me-2"></i>Período</label>
                <div class="info-row"><span class="info-label">Fecha Inicio:</span><span class="info-value"><?php echo $fechaInicio ? date('d/m/Y',strtotime($fechaInicio)) : 'N/A'; ?></span></div>
                <div class="info-row"><span class="info-label">Fecha Fin:</span><span class="info-value"><?php echo $fechaFin ? date('d/m/Y',strtotime($fechaFin)) : '<span class="badge bg-success">Activo</span>'; ?></span></div>
            </div>
        </div>
    </div>
</div>

<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sidebar.js"></script>
</body>
</html>