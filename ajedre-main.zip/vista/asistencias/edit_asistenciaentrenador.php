<?php
session_start();
// Verificar sesión antes de mostrar el dashboard
include_once("../../controlador/verificar_sesion.php");
include("../../modelo/conexion.php");

$id           = isset($_GET['id']) ? base64_decode($_GET['id']) : '';
$idEntrenador = isset($_GET['idEntrenador']) ? base64_decode($_GET['idEntrenador']) : '';
$fecha        = isset($_GET['fecha']) ? base64_decode($_GET['fecha']) : '';
$entrada      = isset($_GET['entrada']) ? base64_decode($_GET['entrada']) : '';
$salida       = isset($_GET['salida']) ? base64_decode($_GET['salida']) : '';
$alumnos      = isset($_GET['alumnos']) ? base64_decode($_GET['alumnos']) : '';
$obs          = isset($_GET['obs']) ? base64_decode($_GET['obs']) : '';

try {
    $stmt = $conex->prepare("SELECT idEntrenador, cedula, nombre, apellido FROM ENTRENADOR ORDER BY apellido ASC, nombre ASC");
    $stmt->execute();
    $entrenadores = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $entrenadores = [];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include '../assets/inc/head.php'; ?>
</head>

<body>
<div class="page-container">

    <!-- SIDEBAR -->
    <?php include '../assets/inc/sidebar.php'; ?>

    <!-- HEADER -->
    <?php include '../assets/inc/header.php'; ?>

    <!-- MAIN -->
    <div class="main-content">

        <div class="catalog-header">
            <h1 class="page-title">
                <i class="fas fa-edit me-2"></i> Editar Asistencia Entrenador
            </h1>

            <a href="./asistencia.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-2"></i> Volver
            </a>
        </div>

        <div class="form-card">

            <form method="POST" action="../../controlador/ctl_asistencia_entrenador.php" onsubmit="return validarEditarAsistenciaEntrenador(event)">
                <input type="hidden" name="actualizar" value="actualizar">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars(base64_encode($id)); ?>">

                <h3 class="section-title">Datos de Asistencia</h3>

                <!-- ENTRENADOR -->
                <div class="mb-3">
                    <label class="form-label required-star">Entrenador</label>
                    <select class="form-select" id="idEntrenador" name="idEntrenador" required>
                        <option value="">Seleccionar entrenador</option>
                        <?php foreach($entrenadores as $e): ?>
                            <option value="<?php echo $e['idEntrenador']; ?>" <?php echo $e['idEntrenador'] == $idEntrenador ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($e['cedula'].' - '.$e['nombre'].' '.$e['apellido']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback-real" id="idEntrenadorFeedback"></div>
                </div>

                <!-- FECHA -->
                <div class="mb-3">
                    <label class="form-label required-star">Fecha</label>
                    <input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo htmlspecialchars($fecha); ?>" required>
                    <div class="invalid-feedback-real" id="fechaFeedback"></div>
                </div>

                <!-- HORA -->
                <div class="mb-3">
                    <label class="form-label required-star">Hora</label>
                    <input type="text" class="form-control" id="hora" name="horaEntrada" value="<?php echo htmlspecialchars($entrada ? date("h:i A", strtotime($entrada)) : ''); ?>" placeholder="Ej: 09:00 AM" required>
                    <div class="invalid-feedback-real" id="horaFeedback"></div>
                </div>

                <!-- ALUMNOS -->
                <div class="mb-3">
                    <label class="form-label required-star">Alumnos entrenados</label>
                    <input type="number" class="form-control" id="alumnosEntrenados" name="alumnosEntrenados" min="0" value="<?php echo htmlspecialchars($alumnos); ?>" required>
                    <div class="invalid-feedback-real" id="alumnosEntrenadosFeedback"></div>
                </div>

                <!-- OBSERVACIÓN -->
                <div class="mb-3">
                    <label class="form-label">Observación</label>
                    <textarea class="form-control" id="observacion" name="observacion" placeholder="Escriba la observación (opcional)"><?php echo htmlspecialchars($obs); ?></textarea>
                    <div class="invalid-feedback-real" id="observacionFeedback"></div>
                </div>

                <!-- BOTONES -->
                <div class="form-actions">
                    <button type="reset" class="btn btn-danger" id="resetBtn">
                        <i class="fas fa-eraser me-2"></i> Limpiar
                    </button>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i> Actualizar
                    </button>
                </div>

            </form>

        </div>

    </div>

</div>

<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sweetalert2.all.min.js"></script>
<script src="../assets/js/sidebar.js"></script>
<script src="../assets/js/validaciones_editasistenciaentrenador.js"></script>

</body>
</html>