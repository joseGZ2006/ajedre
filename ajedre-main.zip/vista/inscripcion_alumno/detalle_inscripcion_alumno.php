<?php
session_start();
// Verificar sesión antes de mostrar el dashboard
include_once("../../controlador/verificar_sesion.php");

// Decodificar los parámetros recibidos
$id      = isset($_GET['id'])       ? base64_decode($_GET['id'])      : '';
$alumno  = isset($_GET['alumno'])   ? base64_decode($_GET['alumno'])  : '';
$cedula  = isset($_GET['cedula'])   ? base64_decode($_GET['cedula'])  : '';
$club    = isset($_GET['club'])     ? base64_decode($_GET['club'])    : 'N/A';
$fecha   = isset($_GET['fecha'])    ? base64_decode($_GET['fecha'])   : '';
$estatus = isset($_GET['estatus'])  ? base64_decode($_GET['estatus']) : '';
$correo  = isset($_GET['correo'])   ? base64_decode($_GET['correo'])  : 'N/A';
$telefono= isset($_GET['telefono']) ? base64_decode($_GET['telefono']): 'N/A';

if (empty($id)) {
    $_SESSION['flash'] = ['icon' => 'error', 'title' => 'Error', 'text' => 'Inscripción no encontrada o ID inválido.'];
    header("Location: ./inscripcion_alumno.php");
    exit;
}

function getEstatusBadge($estatus) {
    $clases = [
        'activo'     => 'bg-success',
        'inactivo'   => 'bg-danger',
        'suspendido' => 'bg-warning text-dark',
    ];
    return isset($clases[$estatus]) ? $clases[$estatus] : 'bg-secondary';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include '../assets/inc/head.php'; ?>
</head>

<body>
<div class="page-container">

    <!-- SIDEBAR -->
    <?php include '../assets/inc/sidebar.php'; ?>

    <!-- HEADER -->
    <?php include '../assets/inc/header.php'; ?>

    <!-- CONTENIDO -->
    <div class="main-content">
        <div class="detail-header">
            <div class="catalog-header">
                <h1 class="page-title">
                    <i class="fas fa-info-circle me-2"></i> Detalle de Inscripción
                </h1>
            </div>
            <a href="./inscripcion_alumno.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-2"></i>Volver al catálogo
            </a>
        </div>

        <!-- AVATAR / ICONO -->
        <div class="detail-avatar">
            <div class="avatar-large">
                <i class="fas fa-user-plus"></i>
            </div>
            <h2><?php echo htmlspecialchars($alumno); ?></h2>
            <p class="text-muted">Cédula: <?php echo htmlspecialchars($cedula); ?></p>
            <p class="text-muted fw-bold">ID Inscripción: <?php echo htmlspecialchars($id); ?></p>
        </div>

        <!-- INFO -->
        <div class="detail-info-grid">
            <div class="info-group">
                <label>
                    <i class="fas fa-user-check me-2"></i>
                    Información de Inscripción
                </label>
                <div class="info-row">
                    <span class="info-label">Alumno:</span>
                    <span class="info-value"><?php echo htmlspecialchars($alumno); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Cédula:</span>
                    <span class="info-value"><?php echo htmlspecialchars($cedula); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Club:</span>
                    <span class="info-value"><?php echo htmlspecialchars($club); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Correo:</span>
                    <span class="info-value"><?php echo htmlspecialchars($correo); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Teléfono:</span>
                    <span class="info-value"><?php echo htmlspecialchars($telefono); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Fecha de Inscripción:</span>
                    <span class="info-value"><?php echo date('d/m/Y', strtotime($fecha)); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Estatus:</span>
                    <span class="info-value">
                        <span class="badge <?php echo getEstatusBadge($estatus); ?>">
                            <?php echo ucfirst(htmlspecialchars($estatus)); ?>
                        </span>
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sidebar.js"></script>
</body>
</html>
