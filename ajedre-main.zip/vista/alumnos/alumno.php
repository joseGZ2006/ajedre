<?php
session_start();
// Verificar sesión antes de mostrar el dashboard
include_once("../../controlador/verificar_sesion.php");
include_once("../../modelo/conexion.php");


?>
<?php
    // Obtener todos los alumnos
    try {
        $sql = $conex->prepare("SELECT a.*, r.nombre as nombre_representante, r.apellido as apellido_representante
                                FROM ALUMNO a 
                                LEFT JOIN REPRESENTANTE r ON a.idRepresentante = r.idRepresentante 
                                ORDER BY a.apellido, a.nombre");
        $sql->execute();
        $alumnos = $sql->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        $alumnos = [];
        error_log("Error al cargar alumnos: " . $e->getMessage());
    }

   

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include '../assets/inc/head.php'; ?>

</head>

<body>
<div class="page-container">

    <!-- SIDEBAR -->
    <?php include '../assets/inc/sidebar.php'; ?>

    <!-- HEADER -->
    <?php include '../assets/inc/header.php'; ?>

    

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="catalog-header">
            <h1 class="page-title"><i class="fas fa-chess-queen me-2"></i> ALUMNOS</h1>
            <?php if ($_SESSION['rol_ses'] == 'admin' || $_SESSION['rol_ses'] == 'entrenador') {?>
                
                <a href="./insert_alumno.php" class="btn btn-custom"><i class="fas fa-plus-circle me-2"></i>Nuevo Alumno</a>
            <?php }?> 
        </div>
 
        <!-- TABLA DE ALUMNOS -->
        <div class="table-responsive">
            <table class="table alumno-table" id="alumnoTable">
                <thead>
                    <tr>
                        <th>Cédula</th>
                        <th>Nombre Completo</th>
                        <th>Fecha Nac.</th>
                        <th>Edad</th>
                        <th>Estatus</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($alumnos)): ?>
                        <tr>
                            <td colspan="8" class="text-center">No hay alumnos registrados</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($alumnos as $alumno): ?>
                            <tr data-estatus="<?php echo htmlspecialchars($alumno['estatus']); ?>" 
                                data-categoria="<?php echo htmlspecialchars($alumno['categoria']); ?>"
                                data-nombre="<?php echo strtolower(htmlspecialchars($alumno['nombre'] . ' ' . $alumno['apellido'])); ?>"
                                data-cedula="<?php echo htmlspecialchars($alumno['cedula']); ?>">
                                <td><?php echo htmlspecialchars($alumno['cedula']); ?></td>
                                <td><?php echo htmlspecialchars($alumno['nombre'] . ' ' . $alumno['apellido']); ?></td>
                                <td><?php echo date('d/m/Y', strtotime($alumno['fechaNacimiento'])); ?></td>
                                <td><?php echo $alumno['edad']; ?> años</td>
                                <td>
                                    <span class="badge bg-<?php echo $alumno['estatus'] == 'activo' ? 'success' : ($alumno['estatus'] == 'inactivo' ? 'secondary' : 'warning'); ?>">
                                        <?php echo ucfirst($alumno['estatus']); ?>
                                    </span>
                                </td>
                                <td>
                                    <a class="btn btn-sm btn-secondary" href="../../controlador/ctl_alumno.php?C=con&I=<?php echo base64_encode($alumno['cedula']); ?>">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <?php if($_SESSION['rol_ses'] == 'admin') {?>
                                    <a class="btn btn-sm btn-primary" href="../../controlador/ctl_alumno.php?M=mos&I=<?php echo base64_encode($alumno['cedula']); ?>">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button class="btn btn-sm btn-danger btn-delete" data-cedula="<?php echo $alumno['cedula']; ?>" data-nombre="<?php echo htmlspecialchars($alumno['nombre'] . ' ' . $alumno['apellido']); ?>">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../assets/inc/flash.php'; ?>

<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sidebar.js"></script>
<script src="../assets/js/sweetalert2.all.min.js"></script>
<?php include '../assets/inc/eliminar_alumno.php'; ?>


</body>
</html>