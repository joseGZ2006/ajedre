<?php
session_start();
include_once("../../controlador/verificar_sesion.php");

$id  = isset($_GET['id'])  ? base64_decode($_GET['id'])  : '';
$dia = isset($_GET['dia']) ? base64_decode($_GET['dia']) : '';
$hi  = isset($_GET['hi'])  ? base64_decode($_GET['hi'])  : '';
$hf  = isset($_GET['hf'])  ? base64_decode($_GET['hf'])  : '';

if(empty($id)) { $_SESSION['flash']=['icon'=>'error','title'=>'Error','text'=>'Horario no encontrado.']; header("Location: ./horario.php"); exit; }
?>
<!DOCTYPE html>
<html lang="es">
<head><?php include '../assets/inc/head.php'; ?></head>
<body>
<div class="page-container">
    <?php include '../assets/inc/sidebar.php'; ?>
    <?php include '../assets/inc/header.php'; ?>

    <div class="main-content">
        <div class="detail-header">
            <div class="catalog-header">
                <h1 class="page-title"><i class="fas fa-calendar-alt me-2"></i> Detalle de Horario de Clase</h1>
            </div>
            <a href="./horario.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-2"></i>Volver al catálogo</a>
        </div>

        <div class="detail-avatar">
            <div class="avatar-large"><i class="fas fa-calendar-week"></i></div>
            <h2><?php echo htmlspecialchars($dia); ?></h2>
            <p class="text-muted">ID Horario: <?php echo htmlspecialchars($id); ?></p>
        </div>

        <div class="detail-info-grid">
            <div class="info-group">
                <label><i class="fas fa-clock me-2"></i>Información del Horario</label>
                <div class="info-row">
                    <span class="info-label">Día de la Semana:</span>
                    <span class="info-value"><?php echo htmlspecialchars($dia); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Hora de Inicio:</span>
                    <span class="info-value"><?php echo $hi ? date('h:i A', strtotime($hi)) : 'N/A'; ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Hora de Fin:</span>
                    <span class="info-value"><?php echo $hf ? date('h:i A', strtotime($hf)) : 'N/A'; ?></span>
                </div>
                <?php if($hi && $hf): ?>
                <div class="info-row">
                    <span class="info-label">Duración:</span>
                    <span class="info-value">
                        <?php
                        $diff = (strtotime($hf) - strtotime($hi)) / 60;
                        echo floor($diff/60).'h '.($diff%60).'min';
                        ?>
                    </span>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sidebar.js"></script>
</body>
</html>