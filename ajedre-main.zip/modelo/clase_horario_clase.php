<?php
class HorarioClase {
    public $idHorarioClase, $diaSemana, $horaInicio, $horaFin;

    private $diasPermitidos = ['Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'];

    private function validarDia($dia) {
        return in_array($dia, $this->diasPermitidos);
    }
    private function validarHora($hora) {
        return preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $hora);
    }

    ## REGISTRAR
    public function RegistrarHorarioClase($diaSemana, $horaInicio, $horaFin) {
        include("conexion.php");
        if (!$this->validarDia($diaSemana))
            return ['success' => false, 'error' => 'Día de semana no válido.'];
        if (!$this->validarHora($horaInicio) || !$this->validarHora($horaFin))
            return ['success' => false, 'error' => 'Las horas no tienen formato válido.'];
        if ($horaFin <= $horaInicio)
            return ['success' => false, 'error' => 'La hora de fin debe ser mayor a la hora de inicio.'];
        try {
            $sql = $conex->prepare("INSERT INTO HORARIO_CLASE (diaSemana, horaInicio, horaFin) VALUES (?, ?, ?)");
            $ok  = $sql->execute([$diaSemana, $horaInicio, $horaFin]);
            return $ok ? ['success' => true] : ['success' => false, 'error' => 'Error al registrar.'];
        } catch (PDOException $e) {
            error_log("Error RegistrarHorarioClase: " . $e->getMessage());
            return ['success' => false, 'error' => 'Error en la base de datos.'];
        }
    }

    ## LISTAR
    public function ListarHorariosClase() {
        include("conexion.php");
        try {
            $sql = $conex->prepare("SELECT * FROM HORARIO_CLASE ORDER BY FIELD(diaSemana,'Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'), horaInicio");
            $sql->execute();
            return $sql->rowCount() > 0 ? $sql->fetchAll(PDO::FETCH_ASSOC) : false;
        } catch (PDOException $e) {
            error_log("Error ListarHorariosClase: " . $e->getMessage());
            return false;
        }
    }

    ## CONSULTAR
    public function ConsultarHorarioClase($id) {
        include("conexion.php");
        try {
            $sql = $conex->prepare("SELECT * FROM HORARIO_CLASE WHERE idHorarioClase = ?");
            $sql->execute([$id]);
            return $sql->rowCount() > 0 ? $sql->fetch(PDO::FETCH_ASSOC) : false;
        } catch (PDOException $e) {
            error_log("Error ConsultarHorarioClase: " . $e->getMessage());
            return false;
        }
    }

    ## ACTUALIZAR
    public function ActualizarHorarioClase($id, $diaSemana, $horaInicio, $horaFin) {
        include("conexion.php");
        if (!$this->validarDia($diaSemana))
            return ['success' => false, 'error' => 'Día de semana no válido.'];
        if (!$this->validarHora($horaInicio) || !$this->validarHora($horaFin))
            return ['success' => false, 'error' => 'Las horas no tienen formato válido.'];
        if ($horaFin <= $horaInicio)
            return ['success' => false, 'error' => 'La hora de fin debe ser mayor a la hora de inicio.'];
        try {
            $sql = $conex->prepare("UPDATE HORARIO_CLASE SET diaSemana=?, horaInicio=?, horaFin=? WHERE idHorarioClase=?");
            $ok  = $sql->execute([$diaSemana, $horaInicio, $horaFin, $id]);
            return $ok ? ['success' => true] : ['success' => false, 'error' => 'Error al actualizar.'];
        } catch (PDOException $e) {
            error_log("Error ActualizarHorarioClase: " . $e->getMessage());
            return ['success' => false, 'error' => 'Error en la base de datos.'];
        }
    }

    ## ELIMINAR
    public function EliminarHorarioClase($id) {
        include("conexion.php");
        try {
            $sql = $conex->prepare("DELETE FROM HORARIO_CLASE WHERE idHorarioClase = ?");
            $ok  = $sql->execute([$id]);
            return $ok ? ['success' => true] : ['success' => false, 'error' => 'Error al eliminar.'];
        } catch (PDOException $e) {
            error_log("Error EliminarHorarioClase: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}
?>
